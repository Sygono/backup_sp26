using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public struct PatrolData
{
    public List<Vector3> points;
    public int pointer;
    public bool loop;
    public bool Finished => pointer == -1 || points == null || points.Count == 0;
    public float stoppingDistance;


    public Vector3 GetCurrentPoint()
    {
        return this.points[this.pointer];
    }

    public void MoveNext()
    {
        this.pointer += 1;
        if (!this.loop && this.pointer >= this.points.Count)
        {
            pointer = -1;
            return;
        }
        this.pointer = this.pointer % this.points.Count;
    }

    public bool Equals(PatrolData other)
    {
        if (loop != other.loop) return false;

        if (points == null && other.points == null) return true;
        if (points == null || other.points == null) return false;
        if (points.Count != other.points.Count) return false;

        for (int i = 0; i < points.Count; i++)
        {
            if (points[i] != other.points[i]) // Vector3 already has ==/!=
                return false;
        }

        return true;
    }
}

public class PatrolPointsSystem : MonoBehaviour
{
    public PatrolData patrolData;
    private MoveToPositionSystem moveToPositionSystem;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        moveToPositionSystem = GetComponent<MoveToPositionSystem>();
    }

    void Update()
    {

        if (!patrolData.Finished)
        {
            var targetPoint = patrolData.GetCurrentPoint();
            if (Vector3.Distance(transform.position, targetPoint) <= patrolData.stoppingDistance)
            {
                patrolData.MoveNext();
                return;
            }
            moveToPositionSystem.moveToPositionData = new MoveToPositionData
            {
                destination = targetPoint,
                stoppingDistance = patrolData.stoppingDistance,
            };
        }
    }
}
