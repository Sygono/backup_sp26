using System.Collections.Generic;
using UnityEngine;

public class ObserveSystem : MonoBehaviour
{
    [Header("Query")]
    [SerializeField] public float radius = 10f;
    [SerializeField] public LayerMask layerMask = ~0;
    [SerializeField] public QueryTriggerInteraction triggerInteraction = QueryTriggerInteraction.Ignore;

    // start capacity for non-alloc query; grows if needed
    [SerializeField] public int initialBufferSize = 64;

    private Collider[] _hits;
    private readonly Dictionary<TeamId, int> _counts = new();
    private readonly HashSet<Entity> _seenEntities = new(); // dedupe entities with multiple colliders

    public IReadOnlyDictionary<TeamId, int> Counts => _counts;
    public int GetCount(TeamId team) => _counts.TryGetValue(team, out var n) ? n : 0;

    void Awake()
    {
        _hits = new Collider[Mathf.Max(8, initialBufferSize)];
    }

    void Update()
    {
        // Reset (Option A style)
        _counts.Clear();
        _seenEntities.Clear();

        // Non-alloc sphere query, auto-grow when full
        int hitCount;
        while (true)
        {
            hitCount = Physics.OverlapSphereNonAlloc(
                transform.position, radius, _hits, layerMask, triggerInteraction);

            if (hitCount < _hits.Length) break; // buffer big enough
                                                // grow buffer and retry
            _hits = new Collider[_hits.Length * 2];
        }

        for (int i = 0; i < hitCount; i++)
        {
            var col = _hits[i];
            if (!col) continue;

            // Find the Entity once per collider; prefer parent search
            var entity = col.GetComponentInParent<Entity>();
            if (entity == null) continue;

            // Deduplicate entities with multiple colliders
            if (!_seenEntities.Add(entity)) continue;

            if (!entity.TryGetData<TeamComponent>(out var teamC)) continue;

            if (_counts.TryGetValue(teamC.team, out var n)) _counts[teamC.team] = n + 1;
            else _counts[teamC.team] = 1;
        }
    }

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, radius);
    }
#endif
}
