using System;
using UnityEngine;

[Serializable]
public struct MovementData
{
    public float maxSpeed;
    public float maxAccel;
}
public class MovementSystem : MonoBehaviour
{
    Rigidbody rb;
    public MovementData data;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public Vector3 netForce;
    public float MaxSpeed => data.maxSpeed;
    public float MaxAccel => data.maxAccel;
    public Vector3 Velovity => rb.linearVelocity;
    public bool stopFlag = false;
    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (stopFlag)
        {
            if (rb.linearVelocity.magnitude > MaxAccel * Time.fixedDeltaTime)
            {
                netForce = -rb.linearVelocity.normalized * MaxAccel;
                rb.AddForce(netForce, ForceMode.Acceleration);
                rb.linearVelocity = Vector3.ClampMagnitude(rb.linearVelocity, MaxSpeed);
            }
            else
            {
                rb.linearVelocity = Vector3.zero;
            }
        } else
        {
            var goalVelocity = netForce.normalized * MaxSpeed;
            var accel = Vector3.ClampMagnitude((goalVelocity - rb.linearVelocity)/Time.fixedDeltaTime, MaxAccel);
            rb.AddForce(accel, ForceMode.Acceleration);
            rb.linearVelocity = Vector3.ClampMagnitude(rb.linearVelocity, MaxSpeed);
        }




        netForce = new Vector3();
        stopFlag = false;
    }



    public void AddForce(Vector3 force)
    {
        // force = Vector3.ClampMagnitude(force, data.maxAccel);
        netForce += force;
    }
}
