using System;
using UnityEngine;

[Serializable]
public struct MoveToPositionData
{
    public Vector3 destination;
    public float stoppingDistance;
    public bool isReached;
}
public class MoveToPositionSystem : MonoBehaviour
{
    public MoveToPositionData moveToPositionData;
    //private MovementSystem movementSystem;
    private MoveAgent agent;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        //movementSystem = GetComponent<MovementSystem>();
        agent = GetComponent<MoveAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        if (moveToPositionData.isReached) return;
        if (Vector3.Distance(transform.position, moveToPositionData.destination) <= moveToPositionData.stoppingDistance)
        {
            moveToPositionData.isReached = true;
            return;
        }
        agent.StartMove(moveToPositionData.destination);
        //var toTarget = (moveToPositionData.destination - transform.position).normalized;
        //movementSystem.AddForce(toTarget * movementSystem.MaxAccel);
    }
}
