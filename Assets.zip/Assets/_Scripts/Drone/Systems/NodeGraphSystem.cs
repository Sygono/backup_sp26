using NewNodes;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

/*    public interface IRWProperty
{
    public string Name { get; set; }
}

public class RWProperty<T> : IRWProperty
{
    public string Name { get; set; }
    public T Value { get; set; }
    public RWProperty(T Value)
    {
        this.Value = Value;
    }
}*/
public class NodeGraph
{
    [SerializeField] public List<Node> nodes = new List<Node>();
    public FlowPort exec;
    private int tickCount = 0;

    public void Compile(NodeGraphSpec spec, GameObject gameObject = null, GameObject level = null)
    {
        nodes = new List<Node>();
        var idToNode = new Dictionary<int, Node>(capacity: spec.nodes?.Count ?? 0);
        foreach (NodeSpec nodeSpec in spec.nodes)
        {
            var node = Node.NewNode(nodeSpec);
            if (node == null) continue; 
            if (node as CoreNode != null && exec == null)
            {
                exec = node.GetFlow("out");
            }
            else if (node as CommandNode != null)
            {
                if (gameObject != null) ((CommandNode)node).BindToGameObject(gameObject);
                if (level != null) ((CommandNode)node).BindToLevel(level);
            }
            // Debug.Log(node.Serialize());
            nodes.Add(node);
            idToNode[nodeSpec.id] = node;
        }

        // TODO: connect ports

        // 2) Connect data ports
        if (spec.dataConnections != null)
        {
            foreach (var c in spec.dataConnections)
            {
                if (!idToNode.TryGetValue(c.fromId, out var fromNode))
                {
                    Debug.LogError($"[Graph Compile] Data connect failed: fromId {c.fromId} not found.");
                    continue;
                }
                if (!idToNode.TryGetValue(c.toId, out var toNode))
                {
                    Debug.LogError($"[Graph Compile] Data connect failed: toId {c.toId} not found.");
                    continue;
                }

                try
                {
                    Node.ConnectPorts(fromNode, c.fromPort, toNode, c.toPort);
                }
                catch (Exception e)
                {
                    Debug.LogError($"[Graph Compile] Data connect {c.fromId}.{c.fromPort} -> {c.toId}.{c.toPort} failed: {e.Message}");
                }
            }
        }

        // 3) Connect flow ports
        if (spec.flowConnections != null)
        {
            foreach (var fc in spec.flowConnections)
            {
                if (!idToNode.TryGetValue(fc.fromId, out var fromNode))
                {
                    Debug.LogError($"[Graph Compile] Flow connect failed: fromId {fc.fromId} not found.");
                    continue;
                }
                if (!idToNode.TryGetValue(fc.toId, out var toNode))
                {
                    Debug.LogError($"[Graph Compile] Flow connect failed: toId {fc.toId} not found.");
                    continue;
                }

                try
                {
                    Node.ConnectFlows(fromNode, fc.fromPort, toNode, fc.toPort);
                }
                catch (Exception e)
                {
                    Debug.LogError($"[Graph Compile] Flow connect {fc.fromId}.{fc.fromPort} -> {fc.toId}.{fc.toPort} failed: {e.Message}");
                }
            }
        }
    }

    public bool Tick()
    {
        if (exec == null)
        {
            return false;
        }
        //Debug.Log(exec.owner);
        exec.Trigger(); // FlowPort will call PrepareData() then Execute(), then chain ��out��
        // Debug.Log($"NodeGraph Tick {tickCount} complete.");
        
        tickCount++;
        return true;
    }
}

public class NodeGraphSystem : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public GameObject level;
    public NodeGraph graph;
    public NodeGraphSpec nodeGraphSpec;

    void Awake()
    {
        graph = new NodeGraph();
        graph.Compile(nodeGraphSpec, this.gameObject, level);
    }   

    void Start()
    {
        //foreach (var node in graph.nodes)
        //{
        //    Debug.Log(node);
        //    if (node as CoreNode != null)
        //    {
        //        var outFlow = node.GetFlow("out");
        //        var testNode = outFlow.connections[0].owner;
        //        Debug.Log($"The {testNode} has owner {((CommandNode)testNode).ownerGameObject}");
        //    }
        //    if (node as CommandNode != null)
        //    {
        //        Debug.Log($"The {node} has owner {((CommandNode)node).ownerGameObject}");
        //    }
        //}
    }

    void Update()
    {
        // Option A: if you reset systems each frame, do it before Tick()
        // e.g., mover.ClearFrameState(); observer system updates in its own Update()

        if (graph.Tick())
        {
            //Debug.Log($"Tick success on {this}");
        }
    }
}

