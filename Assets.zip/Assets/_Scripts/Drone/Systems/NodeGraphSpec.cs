using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public struct NodeSpec
{
    [SerializeField] public NodeType nodeType;   // typeof(Node)
    [SerializeField] public string[] args;     // boxed struct (e.g., new ObserveArgs { team=..., threshold=..., op=... })
    public int id;
}

[CreateAssetMenu(fileName = "NewNodeGraph", menuName = "CustomNodeGraph/NodeGraph")]
public class NodeGraphSpec : ScriptableObject
{
    public int coreNodeId;
    public List<NodeSpec> nodes;
    public List<NodeConnection> dataConnections;
    public List<NodeConnection> flowConnections;
}

[Serializable]
public struct NodeConnection
{
    public const string DefaultFromPort = "out";
    public const string DefaultToPort = "exec";

    public int fromId;
    public string fromPort; // e.g., "out"
    public int toId;
    public string toPort; // e.g., "exec"
}
