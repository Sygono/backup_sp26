using System;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;

public interface IComponent { }

// Box<T> lets us keep a single heap object per component type and return ref T
internal sealed class Box<T> where T : struct
{
    public T Value;
    public Box(in T value) { Value = value; }
}

public sealed class ComponentHandle<T> where T : struct, IComponent
{
    private Box<T> _box;

    public bool IsBound => _box != null;

    public bool Bind(Entity e)
    {
        if (e == null) { _box = null; return false; }
        return e.TryGetBox(out _box);
    }

    public ref T Ref
    {
        get
        {
            if (_box == null) throw new InvalidOperationException($"{typeof(T).Name} handle not bound.");
            return ref _box.Value; // ref to struct, no boxing, no lookup
        }
    }

    public T Value
    {
        get => Ref;
        set => Ref = value;
    }
}
public class Entity : MonoBehaviour
{
    private readonly Dictionary<Type, object> _components = new();

    public void SetData<T>(in T data) where T : struct, IComponent
    {
        var t = typeof(T);
        if (_components.TryGetValue(t, out var o))
            ((Box<T>)o).Value = data;     // overwrite
        else
            _components[t] = new Box<T>(data);
    }

    // --- Read (by value) ---
    public bool TryGetData<T>(out T data) where T : struct, IComponent
    {
        if (_components.TryGetValue(typeof(T), out var o))
        {
            data = ((Box<T>)o).Value;
            return true;
        }
        data = default;
        return false;
    }

    // NEW: fetch the Box<T> itself (so callers can cache it)
    internal bool TryGetBox<T>(out Box<T> box) where T : struct, IComponent
    {
        if (_components.TryGetValue(typeof(T), out var ib))
        { box = (Box<T>)ib; return true; }
        box = null; return false;
    }
}

public struct CombatComponent : IComponent
{
    public float damage;
    public float minDistance;
    public float animationTime;
    public float timeBetweenAttack;
    public int damageType;
    public float lastAttackTime;
}

public struct HitPointsComponent : IComponent
{
    public int max;
    public int current;
}

public struct MoveSpeedComponent : IComponent
{
    public float value;
}

public enum TeamId : int
{
    Neutral = 0,
    TeamA = 1,
    TeamB = 2,
    // add more as needed
}

public struct TeamComponent : IComponent
{
    public TeamId team;
}