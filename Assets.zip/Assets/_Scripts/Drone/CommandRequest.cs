using System;
using System.Data;
using UnityEngine;

[Serializable]
public struct CommandRequest
{
    public CommandType type;
    public CommandStatus status;
    public object args;

    public bool Equals(CommandRequest other)
    {
        return type == other.type && Equals(args, other.args);
    }

    public override bool Equals(object obj)
    {
        return obj is CommandRequest other && Equals(other);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine((int)type, args);
    }
}

public enum CommandType
{
    UNDEFINED = -1,
    MOVE_TO_POSITION = 0,
    ATTACK_TARGET = 1,
    GATHER_RESOURCE = 2,
    PATROL_BY_POINTS = 3
}

public enum CommandStatus
{
    IDLE = 0,
    PLAYING = 1,
    COMPLETE = 2,
    FAIL = 3
}
