using UnityEngine;
using NewNodes;

[RequireComponent(typeof(Entity))]
public class BaseDrone : MonoBehaviour
{
    Entity entity;
    HealthPrinterNode testPrintNode;
    HealthSetterNode testSetNode;

    ObserveNode observeNode;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        entity = GetComponent<Entity>();
        entity.SetData(new HitPointsComponent { max = 100, current = 100 });
        //testPrintNode = ScriptableObject.CreateInstance<HealthPrinterNode>();
        //testPrintNode.ownerGameObject = gameObject;
        //testSetNode = ScriptableObject.CreateInstance<HealthSetterNode>();
        //testSetNode.ownerGameObject = gameObject;
    }

    // Update is called once per frame
    void Update()
    {

    }
}
