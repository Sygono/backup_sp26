using NUnit.Framework;
using UnityEngine;
using System.Collections.Generic;

public class WayPointSystem : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public List<Transform> wayPoints;
}
