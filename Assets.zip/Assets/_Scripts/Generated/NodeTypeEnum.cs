// AUTO-GENERATED FILE. DO NOT EDIT BY HAND.
using System;
using System.Collections.Generic;

public enum NodeType
{
    AddIntNode,
    AddFloatNode,
    AddVector3Node,
    SimpleAddNode,
    AttackNode,
    HealthPrinterNode,
    HealthSetterNode,
    CoreNode,
    DoNothing,
    MultiflowNode,
    ObserveNode,
    PatrolNode,
}

public static class NodeTypeMap
{
    public static readonly Dictionary<NodeType, Type> Map = new()
    {
        { NodeType.AddIntNode, typeof(NewNodes.AddIntNode) },
        { NodeType.AddFloatNode, typeof(NewNodes.AddFloatNode) },
        { NodeType.AddVector3Node, typeof(NewNodes.AddVector3Node) },
        { NodeType.SimpleAddNode, typeof(NewNodes.SimpleAddNode) },
        { NodeType.AttackNode, typeof(NewNodes.AttackNode) },
        { NodeType.HealthPrinterNode, typeof(NewNodes.HealthPrinterNode) },
        { NodeType.HealthSetterNode, typeof(NewNodes.HealthSetterNode) },
        { NodeType.CoreNode, typeof(NewNodes.CoreNode) },
        { NodeType.DoNothing, typeof(NewNodes.DoNothing) },
        { NodeType.MultiflowNode, typeof(NewNodes.MultiflowNode) },
        { NodeType.ObserveNode, typeof(NewNodes.ObserveNode) },
        { NodeType.PatrolNode, typeof(NewNodes.PatrolNode) },
    };
}
