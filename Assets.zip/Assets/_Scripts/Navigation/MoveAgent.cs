using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class MoveAgent : MonoBehaviour
{
    private NavMeshPath navMeshPath;
    private NavMeshAgent agent;

    [Header("follow path")]
    // public Transform targetTransform;
    private Vector3 destination;
    public float cornerTol = 0.25f;
    public float followStrength = 5f;
    private MovementSystem movementSystem;

    [Header("obstacle avoidance")]
    public float obstacleAvoidDistance = 0.25f;
    public float obstacleAvoidRayRadius = 0.5f;
    public float obstacleAvoidStrength = 5f;


    int cornerIndex;
    Coroutine moveCo;

    public bool drawDebugLines;

    private void Awake()
    {
        this.navMeshPath = new NavMeshPath();
        agent = GetComponent<NavMeshAgent>();   
        movementSystem = GetComponent<MovementSystem>();

    }
    private void Start()
    {
        // destination = targetTransform.position;
        // StartMove();
    }
    public void StartMove(Vector3 destination)
    {
        if (this.destination == destination) return;
        this.destination = destination;
        // agent.updatePosition = false;
        // agent.updateRotation = false;

        bool ok = agent.CalculatePath(destination, navMeshPath);
        if (!ok || navMeshPath.corners == null || navMeshPath.corners.Length < 2)
        {
            Debug.LogWarning("Path generation failed.");
            return;
        }

        cornerIndex = 1; // skip current position (corner 0)
        if (moveCo != null) StopCoroutine(moveCo);
        moveCo = StartCoroutine(FollowPath());
    }

    void FixedUpdate()
    {
        if (moveCo == null)
        {
            // Debug.Log("Stopping");
            //var goalAccel = movementSystem.Velovity.normalized * followStrength;
            //movementSystem.AddForce(-goalAccel);
            //movementSystem.stopFlag = true;

        }
    }

    IEnumerator FollowPath()
    {
        // simple, fixed-step steering toward each corner
        var wait = new WaitForFixedUpdate();

        while (cornerIndex < navMeshPath.corners.Length)
        {
            Vector3 pos = transform.position;
            Vector3 target = navMeshPath.corners[cornerIndex];
            target.y = pos.y; // stay on ground

            Vector3 to = target - pos;
            float dist = to.magnitude;

            if (dist <= cornerTol)
            {
                cornerIndex++;
                continue;
            }

            Vector3 accel = to.normalized * followStrength;
            // accel = Vector3.ClampMagnitude(accel, movementSystem.MaxAccel);
            // rb.AddForce(accel, ForceMode.Acceleration);
            movementSystem.AddForce(accel);

            if (drawDebugLines)
            {
                Debug.DrawLine(transform.position, transform.position + accel, Color.yellow);
            }

            // obstacle avoidance
            if (Physics.SphereCast(pos, obstacleAvoidRayRadius, to, out var hit, obstacleAvoidDistance, LayerMask.GetMask("Obstacle")))
            {
                Debug.DrawRay(pos, to.normalized * hit.distance, Color.red);
                var avoiddirection = Vector3.ProjectOnPlane(to, hit.normal).normalized;
                var avoidFroce = avoiddirection * obstacleAvoidStrength;
                movementSystem.AddForce(avoidFroce);
                movementSystem.AddForce(hit.normal * obstacleAvoidStrength * 0.5f);


                if (drawDebugLines)
                {
                    Debug.DrawLine(transform.position, transform.position + avoidFroce, Color.cyan);
                }
            }
            yield return wait;
        }

        // reached destination
        Debug.Log("Reached destination");
        moveCo = null;
    }

    private void OnDrawGizmos()
    {
        if (navMeshPath == null || navMeshPath.corners.Length < 2)
            return;
        Gizmos.color = Color.red;
        for (int i = 0; i < navMeshPath.corners.Length - 1; i++)
        {
            Gizmos.DrawLine(navMeshPath.corners[i], navMeshPath.corners[i + 1]);
        }
    }
}
