using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Pool;

public class BoidAgent : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private List<BoidAgent> neighbors = new();
    public bool drawDebugLines;
    [Header("Neighbor search")]
    [SerializeField] float neighborRadius = 5f;
    [SerializeField] int maxNeighbors = 16;
    [SerializeField] LayerMask boidLayer;          // assign your "Boid" layer
    [SerializeField] int overlapBufferSize = 64;   // tune for your flock size
    Collider[] overlapBuffer;
    public MovementSystem movementSystem;

    [Header("Seperation")]
    public float perceptionRange;
    public float separationStrength;

    [Header("Alignment")]
    public float alignmentStrength;

    [Header("Cohesion")]
    public float cohesionStrength;

    private void Start()
    {
        overlapBuffer = new Collider[overlapBufferSize];
        movementSystem = GetComponent<MovementSystem>();
    }

    private void Update()
    {
        FindNeighbors();
        Separation();
        Alignment();
        Cohesion();
    }

    void FindNeighbors()
    {
        // TODO: Find other agents within range
        neighbors.Clear();

        int count = Physics.OverlapSphereNonAlloc(
            transform.position,
            neighborRadius,
            overlapBuffer,
            boidLayer,
            QueryTriggerInteraction.Collide // include trigger colliders
        );

        // Optional: collect with distances to sort/limit
        var tmp = ListPool<(float, BoidAgent)>.Get(); // simple pool below
        for (int i = 0; i < count; i++)
        {
            var col = overlapBuffer[i];
            if (!col) continue;

            // Prefer attachedRigidbody for child colliders
            var other = col.attachedRigidbody
                ? col.attachedRigidbody.GetComponent<BoidAgent>()
                : col.GetComponentInParent<BoidAgent>();

            if (other == null || other == this) continue;

            float d2 = (other.transform.position - transform.position).sqrMagnitude;
            if (d2 <= neighborRadius * neighborRadius)
                tmp.Add((d2, other));
        }

        // Sort nearest �� farthest and trim
        tmp.Sort((a, b) => a.Item1.CompareTo(b.Item1));
        int take = Mathf.Min(maxNeighbors, tmp.Count);
        for (int i = 0; i < take; i++) neighbors.Add(tmp[i].Item2);

        ListPool<(float, BoidAgent)>.Release(tmp);
        // Debug.Log($"{this.name} Found {neighbors.Count} neighbors");
    }

    void Separation()
    {
        if (separationStrength > 0)
        {
            if (neighbors == null || neighbors.Count <= 0)
                return;
            else
            {
                // Debug.Log("Perception range must be greater than zero.");
                var separationForce = new Vector3();
                foreach (var item in neighbors)
                {
                    var distance = transform.position - item.transform.position;
                    if (distance.magnitude < perceptionRange * separationStrength)
                    {
                        separationForce += distance.normalized * separationStrength;
                    }
                    
                }

                // separationForce = Vector3.ClampMagnitude(separationForce, movementSystem.MaxAccel);
                // rb.AddForce(separationForce, ForceMode.Acceleration);
                movementSystem.AddForce(separationForce);

                if (drawDebugLines)
                {
                    Debug.DrawLine(transform.position, transform.position + separationForce, Color.red);
                }
            }
        }
    }

    private void Alignment()
    {
        if (alignmentStrength > 0)
        {
            if (neighbors == null || neighbors.Count <= 0)
                return;
            else
            {
                var alignmentForce = new Vector3();
                foreach (var item in neighbors)
                {
                    var itemRb = item.gameObject.GetComponent<Rigidbody>();
                    alignmentForce += itemRb.linearVelocity; // Sum all neighbor velocities (Item2 == velocity)
                }
                alignmentForce /= neighbors.Count;
                // alignmentForce -= movementSystem.Velovity;
                alignmentForce *= alignmentStrength;
                // alignmentForce = Vector3.ClampMagnitude(alignmentForce, movementSystem.MaxAccel);
                // rb.AddForce(alignmentForce, ForceMode.Acceleration);
                movementSystem.AddForce(alignmentForce);

                if (drawDebugLines)
                {
                    Debug.DrawLine(transform.position, transform.position + alignmentForce, Color.green);
                }
            }
        }
    }

    private void Cohesion()
    {
        if (cohesionStrength > 0)
        {
            if (neighbors == null || neighbors.Count <= 0)
                return;
            else
            {
                var cohesionForce = new Vector3();
                foreach (var item in neighbors)
                {
                    cohesionForce += item.transform.position; // Sum all neighbor positions (Item1 == position)
                }
                cohesionForce /= neighbors.Count;   // Get average position (center)
                cohesionForce -= transform.position; // Convert to a vector pointing from boid to center
                cohesionForce *= cohesionStrength;
                // cohesionForce = Vector3.ClampMagnitude(cohesionForce, movementSystem.MaxAccel);
                // rb.AddForce(cohesionForce, ForceMode.Acceleration);
                movementSystem.AddForce(cohesionForce);
                if (drawDebugLines)
                {
                    Debug.DrawLine(transform.position, transform.position + cohesionForce, Color.blue);
                }
            }
        }
    }
}
