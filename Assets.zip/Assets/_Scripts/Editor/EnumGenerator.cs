#if UNITY_EDITOR
using UnityEditor;
using System.IO;
using System;
using System.Linq;
using System.Reflection;
using UnityEngine;
using NewNodes;
public static class NodeEnumGenerator
{
    private const string enumPath = "Assets/_Scripts/Generated/NodeTypeEnum.cs";

    public static Type[] GetAllNodeTypes()
    {
        return Assembly.GetAssembly(typeof(Node))
            .GetTypes()
            .Where(t => t.IsSubclassOf(typeof(Node)) && !t.IsAbstract)
            .ToArray();
    }

    [MenuItem("Tools/Generate NodeType Enum")]
    public static void Generate()
    {
        var nodeBaseType = typeof(Node);
        var nodeTypes = Assembly.GetAssembly(nodeBaseType)
            .GetTypes()
            .Where(t => t.IsSubclassOf(nodeBaseType) && !t.IsAbstract)
            .ToArray();

        using (var writer = new StreamWriter(enumPath))
        {
            writer.WriteLine("// AUTO-GENERATED FILE. DO NOT EDIT BY HAND.");
            writer.WriteLine("using System;");
            writer.WriteLine("using System.Collections.Generic;");
            writer.WriteLine();
            writer.WriteLine("public enum NodeType");
            writer.WriteLine("{");
            foreach (var type in nodeTypes)
                writer.WriteLine($"    {type.Name},");
            writer.WriteLine("}");
            writer.WriteLine();
            writer.WriteLine("public static class NodeTypeMap");
            writer.WriteLine("{");
            writer.WriteLine("    public static readonly Dictionary<NodeType, Type> Map = new()");
            writer.WriteLine("    {");
            foreach (var type in nodeTypes)
                writer.WriteLine($"        {{ NodeType.{type.Name}, typeof({type.FullName}) }},");
            writer.WriteLine("    };");
            writer.WriteLine("}");
        }

        AssetDatabase.Refresh();
        UnityEngine.Debug.Log($"NodeType enum + map generated at {enumPath}");
    }
    //public static void GenerateEnum()
    //{
    //    var nodeTypes = NodeEnumGenerator.GetAllNodeTypes();

    //    using (var writer = new StreamWriter(enumPath))
    //    {
    //        writer.WriteLine("public enum NodeType");
    //        writer.WriteLine("{");

    //        foreach (var type in nodeTypes)
    //            writer.WriteLine($"    {type.Name},");

    //        writer.WriteLine("}");
    //    }

    //    AssetDatabase.Refresh();
    //}
}
#endif
