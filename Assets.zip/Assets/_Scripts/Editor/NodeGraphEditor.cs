#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(NodeGraphSpec))]
public class NodeGraphEditor : Editor
{
    SerializedProperty _connections;

    void OnEnable()
    {
        _connections = serializedObject.FindProperty("flowConnections");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        // draw the default inspector (shows Connections list)
        DrawDefaultInspector();

        EditorGUILayout.Space(8);
        using (new EditorGUILayout.HorizontalScope())
        {
            if (GUILayout.Button("Add Default Connection", GUILayout.Height(24)))
            {
                AddDefaultConnection();
            }
        }

        serializedObject.ApplyModifiedProperties();
    }

    private void AddDefaultConnection()
    {
        // record for undo
        Undo.RecordObject(target, "Add Node Connection");

        int index = _connections.arraySize;
        _connections.InsertArrayElementAtIndex(index);
        var el = _connections.GetArrayElementAtIndex(index);

        el.FindPropertyRelative("fromId").intValue = 0; // you can choose a sensible default
        el.FindPropertyRelative("toId").intValue = 0;

        el.FindPropertyRelative("fromPort").stringValue = NodeConnection.DefaultFromPort;
        el.FindPropertyRelative("toPort").stringValue = NodeConnection.DefaultToPort;

        // mark dirty so asset saves
        EditorUtility.SetDirty(target);
    }
}
#endif
