using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Linq.Expressions;
using UnityEngine;

namespace NewNodes
{
    public class MultiflowNode : Node
    {
        [Port(IO.Input)]
        private int a;

        [Port(IO.Input)]
        private int b;

        [Port(IO.Input)]
        private int c;

        [Port(IO.Output)]
        private int output;

        [Port(IO.Input)]
        private Action func1;

        [Port(IO.Input)]
        private Action func2;

        [Port(IO.Output)]
        private Action out1;

        [Port(IO.Output)]
        private Action out2;

        public MultiflowNode() : base()
        {
            func2 = () =>
            {
                output = c + b;
                out2?.Invoke();
            };

            func1 = () =>
            {
                output = a + b;
                out1?.Invoke();
            };
        }
    }
}