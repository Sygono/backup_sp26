using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Unity.Properties;
using Unity.VisualScripting;
using UnityEngine;

namespace NewNodes
{
    public enum ComparisonOp { Less, LessOrEqual, Equal, GreaterOrEqual, Greater, NotEqual }

    // [CreateAssetMenu(fileName = "ObserveNode", menuName = "CustomNode/Observe")]
    public sealed class ObserveNode : CommandNode
    {
        [SerializeField] private ObserveSystem observeSystemOverride;

        [Port(IO.Input)] public TeamId team = TeamId.TeamA;
        [Port(IO.Input)] public int threshold = 1;
        [SerializeField] public ComparisonOp op = ComparisonOp.GreaterOrEqual;

        private ObserveSystem _observe;

        public ObserveNode() : base()
        {
            // Default constructor for serialization
        }

        //public ObserveNode(TeamId _team, int _threshold, ComparisonOp _op) : base()
        //{
        //    team = _team;
        //    threshold = _threshold;
        //    op = _op;   
        //}


        public override void ReadArgs(string[] args)
        {
            team = Enum.Parse<TeamId>(args[0], ignoreCase: true);
            threshold = int.Parse(args[1]);
            op = Enum.Parse<ComparisonOp>(args[2], ignoreCase: true);
        }
        public override void InitializeFlows()
        {
            // Custom wiring: input triggers Execute() ONLY; we decide when to propagate.
            base.InitializeFlows();
            //Action exec = () =>
            //{
            //    this.PrepareData();
            //    this.Execute();
            //};
            //flowPorts["exec"].SetTrigger(exec);

        }

        public override void Execute()
        {
            // Resolve the ObserveSystem (cache after first resolve)
            if (_observe == null)
            {
                _observe = observeSystemOverride
                           ?? (Owner ? Owner.GetComponent<ObserveSystem>() : null)
                           ?? (Owner ? Owner.GetComponentInChildren<ObserveSystem>() : null);
                if (_observe == null)
                {
                    Debug.LogWarning($"{name}: No ObserveSystem found on owner.");
                    return;
                }
            }

            int count = _observe.GetCount(team);
            if (Matches(count, threshold, op))
            {
                // Only now propagate to connected children
                flowPorts["out"].Trigger();
            }
        }

        private static bool Matches(int count, int target, ComparisonOp op)
        {
            return op switch
            {
                ComparisonOp.Less => count < target,
                ComparisonOp.LessOrEqual => count <= target,
                ComparisonOp.Equal => count == target,
                ComparisonOp.GreaterOrEqual => count >= target,
                ComparisonOp.Greater => count > target,
                ComparisonOp.NotEqual => count != target,
                _ => false
            };
        }
    }
}
