using UnityEngine;
using System;

namespace NewNodes
{
    public class CoreNode : Node
    {
        public override void InitializeFlows()
        {
            var fpOut = new FlowPort(IO.Output);
            flowPorts["out"] = fpOut;
            // fpOut.SetOwner(this);
        }
    }
}
