using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Linq.Expressions;
using UnityEngine;

namespace NewNodes
{
    [Serializable]
    public class FlowPort
    {
        public IO direction;
        public Node owner;
        private Action trigger;
        public readonly List<FlowPort> connections = new();

        private Action action;
        private Func<Node, Action> actionGetter;

        public FlowPort(IO direction)
        {
            this.direction = direction;
        }

        public FlowPort(IO direction, FieldInfo fieldInfo, Type ownerType)
        {
            this.direction = direction;
           
            if (direction == IO.Input)
            {
                var nodeParam = Expression.Parameter(typeof(Node), "owner");
                var castOwner = Expression.Convert(nodeParam, ownerType);
                Expression access = Expression.Field(castOwner, fieldInfo);
                actionGetter = Expression.Lambda<Func<Node, Action>>(access, nodeParam).Compile();
            }
        }

        public FlowPort Clone()
        {
            return new FlowPort(this.direction, this.actionGetter);
        }

        public FlowPort(IO direction, Func<Node, Action> actionGetter)
        {
            this.direction = direction;
            this.actionGetter = actionGetter;
        }

        public void SetOwner(Node owner)
        {
            this.owner = owner;
            if (direction == IO.Input)
            {
                if (actionGetter != null)
                {
                    Debug.Log("Action getter exists!");
                    action = () =>
                    {
                        owner.PrepareData();
                        actionGetter(this.owner)?.Invoke();
                    };
                } else
                {
                    // Debug.Log("Action getter is null");
                }
            }
        }

        //public void SetTrigger(Action method) => trigger = () =>
        //{
        //    owner.PrepareData(); // ← This ensures inputs are valid
        //    method?.Invoke();
        //};

        public void SetAction(Action method) => action = () =>
        {
            owner.PrepareData(); // ← This ensures inputs are valid
            method?.Invoke();
        };

        public void ConnectTo(FlowPort target)
        {
            if (this.direction != IO.Output || target.direction != IO.Input)
            {
                throw new InvalidOperationException("FlowPort connections must go from Output to Input.");
            }
            connections.Add(target);
        }

        public void Disconnect(FlowPort target)
        {
            connections.Remove(target);
        }

        //public void Trigger()
        //{
        //    if (direction == IO.Input)
        //    {
        //        trigger?.Invoke();
        //    }
        //    else if (direction == IO.Output)
        //    {
        //        foreach (var conn in connections)
        //            conn.Trigger();
        //    }
        //}

        public void Trigger()
        {
            if (direction == IO.Input)
            {
                action?.Invoke();
            }
            else if (direction == IO.Output)
            {
                foreach (var conn in connections)
                    conn.Trigger();
            }
        }

        public void ClearConnections()
        {
            connections.Clear();
        }
    }
}