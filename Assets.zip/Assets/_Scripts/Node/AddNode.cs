using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Linq.Expressions;
using UnityEngine;

namespace NewNodes
{
    public abstract class AddNode<T> : Node, IPureNode where T : struct
    {

        [Port(IO.Input)]
        private List<T> _inputs;

        [Port(IO.Output)]
        private T _output;

        public override void Execute()
        {
            T result = _inputs[0];
            for (int i = 1; i < _inputs.Count; i++)
            {
                T value = _inputs[i];
                result = Operator<T>.Add(result, value);
            }
            _output = result;
        }
    }

    // [CreateAssetMenu(fileName = "NewAddIntNode", menuName = "CustomNode/AddIntNode")]
    public class AddIntNode : AddNode<int>, IReflectParentFields { }

    // [CreateAssetMenu(fileName = "NewAddFloatNode", menuName = "CustomNode/AddFloatNode")]
    public class AddFloatNode : AddNode<float>, IReflectParentFields { }

    // [CreateAssetMenu(fileName = "NewAddVector3Node", menuName = "CustomNode/AddVector3Node")]
    public class AddVector3Node : AddNode<Vector3>, IReflectParentFields { }

    public class SimpleAddNode : Node, IPureNode
    {
        [Port(IO.Input)]
        [SerializeField]
        public int a;

        [Port(IO.Input)]
        [SerializeField]
        public int b;

        [Port(IO.Output)]
        private int output;

        public SimpleAddNode() : base()
        {
        }

        public override void Execute()
        {
            output = a + b;
            Debug.Log($"SimpleAddNode executed: {a} + {b} = {output}");
        }
    }

    public static class Operator<T>
    {
        public static readonly Func<T, T, T> Add;

        static Operator()
        {
            try
            {
                // (a, b) => a + b
                var a = Expression.Parameter(typeof(T), "a");
                var b = Expression.Parameter(typeof(T), "b");
                var body = Expression.Add(a, b);
                Add = Expression.Lambda<Func<T, T, T>>(body, a, b).Compile();
            }
            catch (Exception)
            {
                Add = (_, _) => throw new NotSupportedException($"Addition not supported for type {typeof(T)}");
            }
        }
    }
}