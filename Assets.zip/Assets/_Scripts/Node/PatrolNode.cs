using NUnit.Framework;
using System;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.UI.GridLayoutGroup;

namespace NewNodes
{
    public class PatrolNode : CommandNode {
        [SerializeField] private PatrolPointsSystem patrolPointsSystem;
        [SerializeField] public bool loop;
        [SerializeField] public List<int> pointIDs;
        [SerializeField] public List<Vector3> pointPositions;

        public override void BindToGameObject(GameObject owner)
        {
            base.BindToGameObject(owner);
            patrolPointsSystem = ownerGameObject.GetComponent<PatrolPointsSystem>();
            // Debug.Log(patrolPointsSystem);
        }
        public override void BindToLevel(GameObject level)
        {
            base.BindToLevel(level);
            var wayPointSystem = level.GetComponent<WayPointSystem>();
            pointPositions = new List<Vector3>();
            foreach (int index in pointIDs)
            {
                pointPositions.Add(wayPointSystem.wayPoints[index].position);
                // Debug.Log(wayPointSystem.wayPoints[index]);
            }
        }
        public override void ReadArgs(string[] args)
        {
            loop = args[0] == "1";
            pointIDs = new List<int>();
            pointPositions = new List<Vector3>();
            for (int i = 1; i < args.Length; i++)
            {
                if (int.TryParse(args[i], out int id))
                {
                    pointIDs.Add(id);
                }
            }
        }

        public override void Execute()
        {
            var patrolData = new PatrolData
            {
                points = pointPositions,
                loop = loop,
                stoppingDistance = 0.5f,
            };

            if (!patrolData.Equals(patrolPointsSystem.patrolData))
            {
                patrolPointsSystem.patrolData = patrolData;
            }
        }
    }
}