using NewNodes;  // Adjust to your actual namespace
using System;
using System.Collections.Generic;
using System.Reflection;
using Unity.VisualScripting;
using UnityEngine;

public class SimpleAddNodeTester : MonoBehaviour
{

    void Start()
    {
        Test3();
    }

    void Test3()
    {
        // var addNode1 = Activator.CreateInstance<SimpleAddNode>();
        SimpleAddNode addNode1 = (SimpleAddNode)Node.NewNode<SimpleAddNode>();
        Debug.Log(addNode1);
        var a1 = (NewNodes.DataPort<int>)addNode1.GetPort("a");
        var b1 = (NewNodes.DataPort<int>)addNode1.GetPort("b");
        a1.Getter = () => 2;
        b1.Getter = () => 3;
        addNode1.a = 1; 
        addNode1.b = 2;
        addNode1.PrepareData();
        addNode1.Execute();
        var output1 = (NewNodes.DataPort<int>)addNode1.GetPort("output");
        // int result1 = output1.getterFunc(addNode1);
        int result1 = output1.Getter();
        Debug.Log($"Result of (2 + 3) = {result1}");
        Debug.Log(addNode1.a);
        Debug.Log(addNode1.b);

    }

    //void Test2()
    //{
    //    var addNode1 = ScriptableObject.CreateInstance<SimpleAddNode>();
    //    var a1 = (NewNodes.DataPort<int>)addNode1.GetPort("a");
    //    var b1 = (NewNodes.DataPort<int>)addNode1.GetPort("b");
    //    a1.Getter = () => 2;
    //    b1.Getter = () => 3;
    //    addNode1.PrepareData();
    //    addNode1.Execute();
    //    var output1 = (NewNodes.DataPort<int>)addNode1.GetPort("output");
    //    int result1 = output1.Getter();
    //    Debug.Log($"Result of (2 + 3) = {result1}");
    //    var addNode2 = Node.NodeFromCache(typeof(SimpleAddNode));
    //    addNode2.PrepareData();
    //    addNode2.Execute();
    //    var output2 = (NewNodes.DataPort<int>)addNode2.GetPort("output");
    //    int result2 = output2.Getter();
    //    Debug.Log($"Result of (? + ?) = {result2}");

    //    SimpleAddNode addNode3 = (SimpleAddNode)Node.NodeFromCache(typeof(SimpleAddNode));
    //    addNode3.a = 4;
    //    addNode3.b = 5;
    //    addNode3.PrepareData();
    //    addNode3.Execute();
    //    var output3 = (NewNodes.DataPort<int>)addNode3.GetPort("output");
    //    int result3 = output3.Getter();
    //    Debug.Log($"Result of (4 + 5) = {result3}");

    //}


    //void Test1()
    //{
    //    // Create first add node
    //    var addNode1 = ScriptableObject.CreateInstance<SimpleAddNode>();

    //    // Set constant input using getter
    //    var a1 = (NewNodes.DataPort<int>)addNode1.GetPort("a");
    //    var b1 = (NewNodes.DataPort<int>)addNode1.GetPort("b");
    //    a1.Getter = () => 2;
    //    b1.Getter = () => 3;
    //    //addNode1.Run();
    //    //var output1 = (NewNodes.DataPort<int>)addNode1.GetPort("output");
    //    //int result1 = output1.Getter();
    //    //Debug.Log($"Result of (2 + 3) = {result1}"); // Should print 10

    //    // Create second add node
    //    var addNode2 = ScriptableObject.CreateInstance<SimpleAddNode>();

    //    // Connect output of addNode1 to both inputs of addNode2
    //    NewNodes.Node.ConnectPorts(addNode1, "output", addNode2, "a");
    //    NewNodes.Node.ConnectPorts(addNode1, "output", addNode2, "b");

    //    // Run second node (runs dependencies first)
    //    // addNode2.Run();

    //    // Get the result via the output port getter
    //    var output2 = (NewNodes.DataPort<int>)addNode2.GetPort("output");
    //    int result2 = output2.Getter();

    //    Debug.Log($"Result of (2 + 3) + (2 + 3) = {result2}"); // Should print 10

    //    Debug.Log("Test AddNode<int>");

    //    var addNode3 = ScriptableObject.CreateInstance<AddIntNode>();
    //    var a3 = (NewNodes.DataPort<List<int>>)addNode3.GetPort("_inputs");
    //    a3.Getter = () => new List<int>() { 1, 2, 3 };
    //    // addNode3.Run();
    //    var output3 = (NewNodes.DataPort<int>)addNode3.GetPort("_output");
    //    int result3 = output3.Getter();
    //    Debug.Log($"Result of (1 + 2 + 3) = {result3}");
    //}

    private void SetField<T>(object obj, string fieldName, T value)
    {
        var fieldInfo = obj.GetType().GetField(fieldName, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
        fieldInfo?.SetValue(obj, value);
    }

    private object GetField(object obj, string fieldName)
    {
        var fieldInfo = obj.GetType().GetField(fieldName, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
        return fieldInfo?.GetValue(obj);
    }
}
