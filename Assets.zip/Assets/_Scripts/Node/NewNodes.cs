using System;
using System.Collections; 
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Unity.Properties;
using Unity.VisualScripting;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UI;
using static UnityEditor.MaterialProperty;
using static UnityEngine.EventSystems.StandaloneInputModule;
using static UnityEngine.UI.GridLayoutGroup;

namespace NewNodes {
    
    public interface IPureNode {
    }

    public interface IReflectParentFields { }
    public abstract class Node
    {
        private static Dictionary<Type, Node> nodePrototypesCache = new();
        private static Dictionary<Type, Dictionary<string, IDataPort>> portPrototypesCache = new();

        public Dictionary<string, IDataPort> dataPorts = new();
        public Dictionary<string, FlowPort> flowPorts = new();
        private Dictionary<Node, int> _dependents = new();

        public IDataPort GetPort(string fieldName) => dataPorts.TryGetValue(fieldName, out var port) ? port : null;
        public FlowPort GetFlow(string fieldName) => flowPorts.TryGetValue(fieldName, out var port) ? port : null;

        public virtual string name => this.ToString();

        //public static Node NodeFromCache(Type type)
        //{
        //    //if (!nodePrototypesCache.TryGetValue(type, out var proto))
        //    //{
        //    //    // always use ScriptableObject factory for Unity types
        //    //    proto = (Node)ScriptableObject.CreateInstance(type);
        //    //    if (proto == null)
        //    //        throw new Exception($"Type {type} is not a valid Node type.");

        //    //    nodePrototypesCache[type] = proto;
        //    //}

        //    //// clone the prototype so every caller gets a fresh node
        //    //Node node = Instantiate(proto);
        //    //node.RebindAllPortsToSelf();
        //    //return node;

        //}
        public static Node NewNode(Type nodeType, string[] args = null)
        {
            if (!typeof(Node).IsAssignableFrom(nodeType))
                throw new InvalidOperationException($"{nodeType.Name} is not a Node.");
            if (!nodePrototypesCache.TryGetValue(nodeType, out var proto))
            {
                // always use ScriptableObject factory for Unity types
                proto = (Node)Activator.CreateInstance(nodeType);
                if (proto == null)
                    throw new Exception($"Type {nodeType} is not a valid Node type.");
                proto.Build();
                nodePrototypesCache[nodeType] = proto;
            }
            else
            {

            }
            var node = (Node)Activator.CreateInstance(nodeType);
            node.ClonePorts(proto);

            if (args != null && args.Length > 0)
                node.ReadArgs(args);
            // if (node as IPureNode == null) node.InitializeFlows();
            return node;
        }

        public static Node NewNode<T>(string[] args = null)
        {
            return Node.NewNode(typeof(T), args);
        }

        public static Node NewNode(NodeSpec nodeSpec)
        {
            // assuming nodeSpec.nodeType is your enum
            var type = NodeTypeMap.Map[nodeSpec.nodeType];
            return Node.NewNode(type, nodeSpec.args); // args: string[] expected here
        }

        public virtual void ReadArgs(string[] args)
        {

        }

        public void ClonePorts(Node target)
        {
            // this.dataPorts = target.dataPorts.ToDictionary(entry => entry.Key, entry => entry.Value);
            // this.flowPorts = target.flowPorts.ToDictionary(entry => entry.Key, entry => entry.Value);
            foreach (var kvp in target.dataPorts)
            {
                this.dataPorts[kvp.Key] = kvp.Value.Clone();
                this.dataPorts[kvp.Key].SetOwner(this);
            }
            foreach (var kvp in target.flowPorts)
            {
                this.flowPorts[kvp.Key] = kvp.Value.Clone();
                this.flowPorts[kvp.Key].SetOwner(this);

            }
        }

        protected void BuildPortsFromCache()
        {
            var type = GetType();
            if (this as IReflectParentFields != null) type = type.BaseType;
            if (!portPrototypesCache.TryGetValue(type, out var prototypes))
            {
                prototypes = new Dictionary<string, IDataPort>();
                portPrototypesCache[type] = prototypes;
            }
            Debug.Log(type);

            foreach (var fieldInfo in type.GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public))
            {
                var attr = fieldInfo.GetCustomAttribute<PortAttribute>();
                if (attr == null) continue;

                var fieldType = fieldInfo.FieldType;
                Debug.Log($"{fieldInfo.Name}");

                // -------- Dynamic Port List --------
                /*                if (attr.DynamicPortList)
                                {
                                    var list = (IList)fieldInfo.GetValue(this);
                                    if (list == null) continue;

                                    var elementType = fieldType.GetGenericArguments()[0];
                                    bool isFlow = elementType == typeof(Action);

                                    for (int i = 0; i < list.Count; i++)
                                    {
                                        string key = $"{fieldInfo.Name}[{i}]";

                                        if (isFlow)
                                        {
                                            var fp = new FlowPort(attr.direction);
                                            fp.SetOwner(this);
                                            fp.SetTrigger((Action)list[i]);
                                            flowPorts[key] = fp;
                                        }
                                        else
                                        {
                                            // Get or create prototype only once
                                            if (!prototypes.TryGetValue(fieldInfo.Name, out var prototype))
                                            {
                                                var portType = typeof(DataPort<>).MakeGenericType(elementType);
                                                prototype = (IDataPort)Activator.CreateInstance(portType, attr.direction);
                                                prototypes[fieldInfo.Name] = prototype;
                                            }

                                            var clone = prototype.Clone();
                                            clone.SetOwner(this, fieldInfo, i);
                                            dataPorts[key] = clone;
                                        }
                                    }

                                    continue;
                                }*/

                // -------- Static Ports --------
                if (fieldType == typeof(Action))
                {
                    if (this as IPureNode != null)
                    {
                        Debug.Log("PureNode shouldn't have flows");
                        continue;
                    }
                    Debug.Log("This is action");
                    //var fp = new FlowPort(attr.direction);
                    //fp.SetTrigger((Action)fieldInfo.GetValue(fp.owner));
                    var fp = new FlowPort(attr.direction, fieldInfo, fieldType);
                    flowPorts[fieldInfo.Name] = fp;
                }
                else
                {
                    // Debug.Log("This is data");
                    if (!prototypes.TryGetValue(fieldInfo.Name, out var prototype))
                    {
                        var portType = typeof(DataPort<>).MakeGenericType(fieldType);
                        // compile once against the stable owner 'type' you already computed above
                        prototype = (IDataPort)Activator.CreateInstance(
                            portType,
                            new object[] { attr.direction, fieldInfo, /* listIndex: */ null, /* ownerType: */ type }
                        );
                        prototypes[fieldInfo.Name] = prototype;
                    }

                    var clone = prototype.Clone();   // carries fieldInfo, listIndex=null, ownerType=type
                    dataPorts[fieldInfo.Name] = clone;
                }
            }
        }

        public static void ConnectPorts(Node outputNode, string outputField, Node inputNode, string inputField)
        {
            var outputPort = outputNode.GetPort(outputField);
            var inputPort = inputNode.GetPort(inputField);
            if (outputPort == null || inputPort == null)
                throw new Exception("Port not found or type mismatch");

            inputPort.ConnectTo(outputPort);
            inputNode.AddDependent(outputNode);
        }

        public static void DisconnectPorts(Node outputNode, Node inputNode, string inputField)
        {
            var inputPort = inputNode.GetPort(inputField);
            if (inputPort == null)
                throw new Exception("Port not found or type mismatch");
            inputPort.Disconnect();
            inputNode.RemoveDependent(outputNode);
        }


        public static void ConnectFlows(Node outputNode, string outputField, Node inputNode, string inputField)
        {
            var outputPort = outputNode.GetFlow(outputField);
            var inputPort = inputNode.GetFlow(inputField);
            if (outputPort == null || inputPort == null)
                throw new Exception("FlowPort not found or type mismatch");
            outputPort.ConnectTo(inputPort);
        }

        public static void DisconnectFlows(Node outputNode, string outputField, Node inputNode, string inputField)
        {
            var outputPort = outputNode.GetFlow(outputField);
            var inputPort = inputNode.GetFlow(inputField);
            if (outputPort == null || inputPort == null)
                throw new Exception("FlowPort not found or type mismatch");
            outputPort.Disconnect(inputPort);
        }

        public void RebindAllPortsToSelf()
        {
            foreach (var p in dataPorts.Values)
                p.SetOwner(this);
            foreach (var p in flowPorts.Values)
                p.SetOwner(this);
        }

        public void AddDependent(Node dependent)
        {
            if (dependent as IPureNode == null) return;
            if (!_dependents.ContainsKey(dependent))
                _dependents[dependent] = 0;
            _dependents[dependent] += 1;
        }

        public void RemoveDependent(Node dependent)
        {
            if (_dependents.ContainsKey(dependent))
                _dependents[dependent] -= 1;
            if (_dependents[dependent] == 0)
                _dependents.Remove(dependent);
        }

        public void PrepareData()
        {
            foreach (var dep in _dependents.Keys)
            {
                dep.PrepareData();
                dep.Execute();

            }
            foreach (var port in dataPorts.Values)
            {
                port.GatherData();
            }
        }

        public virtual void Execute()
        {

        }

        public Node()
        {
        }

        public void Build()
        {
            Debug.Log("Build Once!");
            BuildPortsFromCache();
            if (this as IPureNode == null) this.InitializeFlows();
        }

        public virtual void InitializeFlows()
        {
            var fpIn = new FlowPort(IO.Input, ExecActionFactory); // precompiled factory
            var fpOut = new FlowPort(IO.Output);

            flowPorts["exec"] = fpIn;
            flowPorts["out"] = fpOut;
        }

        private static Func<Node, Action> ExecActionFactory => _execFactory ??= (n) => (Action)(() =>
        {
            // Everything is per-instance via `n`, no captured fp variables.
            n.PrepareData();
            n.Execute();
            n.GetFlow("out")?.Trigger();
        });
        private static Func<Node, Action> _execFactory;

        //public virtual void InitializeFlows()
        //{
        //var fpIn = new FlowPort(IO.Input);
        //flowPorts["exec"] = fpIn;
        //fpIn.SetOwner(this);

        //var fpOut = new FlowPort(IO.Output);
        //flowPorts["out"] = fpOut;
        //fpOut.SetOwner(this);

        //Action exec = () =>
        //{
        //    fpIn.owner.PrepareData();
        //    fpIn.owner.Execute();
        //    fpOut.Trigger();
        //};
        //fpIn.SetTrigger(exec);
        //}
    }
}
