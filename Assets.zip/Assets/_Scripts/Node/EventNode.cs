using UnityEngine;

public class EventNode
{
    
}
