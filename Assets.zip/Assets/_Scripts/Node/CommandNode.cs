using UnityEngine;

namespace NewNodes
{
    // base class for command nodes (you probably already have something like this)
    public abstract class CommandNode : Node
    {
        [SerializeField] public GameObject ownerGameObject;
        [SerializeField] public GameObject ownerLevel;


        public GameObject Owner => ownerGameObject;

        public virtual void BindToGameObject(GameObject owner)
        {
            ownerGameObject = owner;
        }

        public virtual void BindToLevel(GameObject level)
        {
            ownerLevel = level;
        }
    }

    public sealed class HealthPrinterNode : CommandNode
    {
        private ComponentHandle<HitPointsComponent> _hp = new();

        public override void BindToGameObject(GameObject owner)
        {
            base.BindToGameObject(owner);
            // Ensure we bind the HitPointsComponent only once
            if (owner != null && !_hp.IsBound)
            {
                _hp.Bind(owner.GetComponent<Entity>());
            }
        }

        public override void Execute()
        {
            if (Owner == null)
            {
                Debug.LogWarning($"{name}: OwnerEntity missing.");
                return;
            }

            // Bind once
            if (!_hp.IsBound && !_hp.Bind(Owner.GetComponent<Entity>()))
            {
                Debug.LogWarning($"{name}: Owner has no HitPointsComponent.");
                return;
            }

            // Fast deref (no lookups):
            ref var hp = ref _hp.Ref;
            Debug.Log($"{name}: {Owner.name} HP = {hp.current}/{hp.max}");
        }
    }

    public sealed class HealthSetterNode : CommandNode
    {
        // Input value: can be wired from another node or edited directly
        [Port(IO.Input)]
        [SerializeField] private int targetValue = 100;

        // Optional: also allow additive mode
        [SerializeField] private bool additive = false;

        // Cached pointer to the owner's HitPointsComponent (bind once, reuse)
        private ComponentHandle<HitPointsComponent> _hp = new();

        public override void BindToGameObject(GameObject owner)
        {
            base.BindToGameObject(owner);
            // Ensure we bind the HitPointsComponent only once
            if (owner != null && !_hp.IsBound)
            {
                _hp.Bind(owner.GetComponent<Entity>());
            }
        }

        public override void Execute()
        {
            if (Owner == null)
            {
                Debug.LogWarning($"{name}: OwnerEntity missing.");
                return;
            }

            // Bind once
            if (!_hp.IsBound && !_hp.Bind(Owner.GetComponent<Entity>()))
            {
                Debug.LogWarning($"{name}: Owner has no HitPointsComponent.");
                return;
            }

            // Data ports (if any) will have filled targetValue before Execute() via PrepareData().
            ref var hp = ref _hp.Ref;

            int newValue = targetValue;
            hp.current = Mathf.Clamp(newValue, 0, hp.max);

            targetValue--;
        }
    }
}
