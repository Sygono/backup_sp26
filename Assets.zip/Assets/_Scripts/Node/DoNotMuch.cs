using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace NewNodes
{
    public class DoNotMuch : Node
    {
        
    }
}