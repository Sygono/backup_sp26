using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace NewNodes
{
    public class DoNothing : Node
    {
        public override void Execute()
        {
            Debug.Log("Doing Nothing.");
        }
    }
}
