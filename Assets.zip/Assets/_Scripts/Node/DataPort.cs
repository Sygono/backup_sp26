using System;
using System.Linq.Expressions;
using System.Reflection;
using UnityEngine;

namespace NewNodes
{
    public enum IO
    {
        Input,
        Output
    }

    [AttributeUsage(AttributeTargets.Field)]
    public class PortAttribute : Attribute
    {
        public IO direction { get; }
        public bool DynamicPortList { get; }

        public PortAttribute(IO direction, bool dynamicPortList = false)
        {
            this.direction = direction;
            DynamicPortList = dynamicPortList;
        }
    }

    public interface IDataPort
    {
        IO Direction { get; set; }
        Type dataType { get; }
        void SetOwner(Node owner);
        void GatherData();
        void ConnectTo(IDataPort target);
        void Disconnect();
        IDataPort Clone();

    }
    public class DataPort<T> : IDataPort
    {
        private readonly IO direction;
        private readonly int? listIndex;
        private readonly Type ownerType;              // stable node type to compile against

        public Node owner;                           // instance set later (same type family)

        public readonly Func<Node, T> getterFunc;    // compiled once
        public readonly Action<Node, T> setterFunc;  // compiled once

        public Func<T> getter;                       // bound to owner (no compile)
        public Action<T> setter;                     // bound to owner (no compile)

        public IO Direction
        {
            get => direction;
            set => throw new InvalidOperationException("direction is immutable.");
        }

        public Type dataType => typeof(T);

        // Compile once using a known ownerType (or default to fieldInfo.DeclaringType).
        public DataPort(IO direction, FieldInfo fieldInfo, int? listIndex = null, Type ownerType = null)
        {
            this.direction = direction;
            this.listIndex = listIndex;
            this.ownerType = ownerType ?? fieldInfo.DeclaringType
                                ?? throw new ArgumentException("Cannot determine owner type.");

            // Build access once against ownerType
            var nodeParam = Expression.Parameter(typeof(Node), "owner");
            var castOwner = Expression.Convert(nodeParam, this.ownerType);
            Expression access = Expression.Field(castOwner, fieldInfo);

            if (listIndex.HasValue)
            {
                var idx = Expression.Constant(listIndex.Value);
                // Works for List<T>. If you need arrays, replace with ArrayIndex path.
                access = Expression.Property(access, "Item", idx);
            }

            if (direction == IO.Input)
            {
                var valueParam = Expression.Parameter(typeof(T), "value");
                var assign = Expression.Assign(access, valueParam);
                setterFunc = Expression.Lambda<Action<Node, T>>(assign, nodeParam, valueParam).Compile();
            }
            else // IO.Output
            {
                getterFunc = Expression.Lambda<Func<Node, T>>(access, nodeParam).Compile();
            }
        }

        public void SetOwner(Node owner)
        {
            if (owner == null) throw new ArgumentNullException(nameof(owner));
            if (ReferenceEquals(this.owner, owner))
                throw new InvalidOperationException("Owner already set.");

            // Optional: assert type compatibility (no recompilation)
            if (!ownerType.IsInstanceOfType(owner))
                throw new InvalidOperationException($"Owner type {owner.GetType().Name} is not {ownerType.Name}.");

            this.owner = owner;

            // Bind instance without recompiling
            if (direction == IO.Input)
                setter = v => setterFunc(this.owner, v);
            else
                getter = () => getterFunc(this.owner);
        }

        public void GatherData()
        {
            if (direction == IO.Input)
            {
                if (setter == null) throw new InvalidOperationException("Owner not set on input port.");
                if (getter == null) return; // unconnected input: keep current value
                setter(getter());
            }
            // Output: no-op
        }

        // Expose for wiring: inputs pull from upstream output��s bound getter.
        public Func<T> Getter
        {
            get => getter;
            set => getter = value;
        }

        public void ConnectTo(IDataPort target)
        {
            if (target is not DataPort<T> outPort)
                throw new InvalidOperationException($"Cannot connect {target.GetType()} to DataPort<{typeof(T)}>.");

            if (this.direction != IO.Input || outPort.direction != IO.Output)
                throw new InvalidOperationException($"Invalid connection: {outPort.direction} -> {this.direction}");

            if (outPort.Getter == null)
                throw new InvalidOperationException("Output port owner not set (getter is null).");

            this.Getter = outPort.Getter;
        }

        public void Disconnect()
        {
            if (direction == IO.Input) Getter = null;
        }

        private DataPort(IO direction, int? listIndex, Type ownerType, Func<Node, T> getterFunc, Action<Node, T> setterFunc)
        {
            this.direction = direction;
            this.listIndex = listIndex;
            this.ownerType = ownerType;
            this.getterFunc = getterFunc;
            this.setterFunc = setterFunc;
        }

        // (Optional) If you keep prototypes:
        public IDataPort Clone()
        {
            // return new DataPort<T>(direction, fieldInfo, listIndex, ownerType);
            return new DataPort<T>(direction, listIndex, ownerType, getterFunc, setterFunc);
        }
    }
}
