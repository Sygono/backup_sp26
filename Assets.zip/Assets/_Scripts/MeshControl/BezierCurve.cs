using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEditor;


public class BezierCurve : MonoBehaviour
{
    public List<Vector3> controlPoints;
    [Range(1,32)]
    public int steps = 16;
    public float controlPointRadius = 0.1f;
    public float tangentLength = 0.5f;

    List<Vector3> curvePoints;
    List<Vector3> tangents;

    public UnityEvent OnChange;

    float length;

    public void Reset() {
        controlPoints = new List<Vector3>();
        for (int i=0; i<4; i++) {
            controlPoints.Add(new Vector3(i*10, 0, 0));
        }
    }


    public void Adjust() {
        for (int i = 0; i < controlPoints.Count; i++) {
            Vector3 v = Handles.PositionHandle(transform.TransformPoint(controlPoints[i]), Quaternion.identity);
            Vector3 newPos = transform.InverseTransformPoint(v);
            if (newPos != controlPoints[i])
            {
                // Record the object for undo purposes
                Undo.RecordObject(this, "Move Control Point");

                // Update the position of the object
                controlPoints[i] = newPos;
                //CalculateCentroid();
                // Mark the object as dirty so changes are saved
                EditorUtility.SetDirty(this);
            }
        }
    }

    public void Change() {
        OnChange.Invoke();
    }

    void CalculateCentroid()
    {
        Vector3 centroid = Vector3.zero;

        // Sum up all point positions
        foreach (Vector3 point in controlPoints)
        {
            centroid += point;
        }

        // Divide by total number of points to get average
        centroid /= controlPoints.Count;

        transform.position += centroid;

        for (int i=0; i<controlPoints.Count; i++) {

            controlPoints[i] -= centroid;
        }
    }

    void Render()
    {
        curvePoints = new List<Vector3>();
        tangents = new List<Vector3>();
        length = 0;

        float n = 1.0f/steps;
        for (float p = 0.0f; p <= 1.0f; p += n)
        {
            (Vector3 point, Vector3 tangent) = Evaluate(p);
            curvePoints.Add(point);
            tangents.Add(tangent);
            if (curvePoints.Count>1) {
                length += Vector3.Distance(curvePoints[curvePoints.Count-1], curvePoints[curvePoints.Count-2]);
            }
        }
    }

    public (Vector3, Vector3) Evaluate(float t) {
        List<List<Vector3>> evaluatedLevels = new List<List<Vector3>>();
        evaluatedLevels.Add(controlPoints);
        List<Vector3> points = controlPoints;
        for (int i = 0; i < controlPoints.Count - 1; i++)
        {
            EvaluateStep(ref points, t);
            evaluatedLevels.Add(points);
        }
        List<Vector3> lastLevel = evaluatedLevels[evaluatedLevels.Count - 1];
        List<Vector3> tangentLevel = evaluatedLevels[evaluatedLevels.Count - 2];
        return (lastLevel[0], (tangentLevel[1] - tangentLevel[0]).normalized);
    }

    // Modify the signature of the method to use ref
    void EvaluateStep(ref List<Vector3> points, float t)
    {
        int n = points.Count;
        if (n == 1)
        {
            return;
        }

        List<Vector3> lerps = new List<Vector3>();
        for (int i = 0; i < n - 1; i++)
        {
            lerps.Add((1.0f - t) * points[i] + t * points[i + 1]);
        }

        // Update the original points list
        points = lerps;
    }

    public (Vector3, Vector3) GetValue(float t) {
        int i = (int)Mathf.Round(t*(steps-1));
        return (curvePoints[i], tangents[i]);
    }

    public float GetLength() {
        return length;
    }

    void OnDrawGizmosSelected() {
        if (controlPoints==null) return;
        if (controlPoints.Count==0) return;
        //Render();  
    }

    void OnDrawGizmos()
    {
        if (controlPoints==null) return;
        if (controlPoints.Count==0) return;
        Render();

        Matrix4x4 matrix = transform.localToWorldMatrix;
        // Apply the transformation matrix to Gizmos
        Gizmos.matrix = matrix;

        // Draw control points
        Gizmos.color = Color.red;
        foreach (Vector3 point in controlPoints)
        {
            Gizmos.DrawSphere(point, controlPointRadius);
        }

        // Drawing the curve
        for (int i = 0; i < curvePoints.Count; i+=1)
        {
            if (i!=curvePoints.Count-1) {
                Debug.DrawLine(transform.TransformPoint(curvePoints[i]), transform.TransformPoint(curvePoints[i + 1]), Color.green);
            } else {
                Debug.DrawLine(transform.TransformPoint(curvePoints[i]), transform.TransformPoint(controlPoints[controlPoints.Count-1]), Color.green);
            }
            Debug.DrawLine(transform.TransformPoint(curvePoints[i]), transform.TransformPoint(curvePoints[i] + tangents[i] * tangentLength), Color.blue);
            Debug.DrawLine(transform.TransformPoint(curvePoints[i]), transform.TransformPoint(curvePoints[i] + Vector3.Cross(tangents[i], Vector3.up) * tangentLength), Color.red);
        }

        Gizmos.color = Color.cyan;
        Gizmos.DrawSphere(Vector3.zero, controlPointRadius*2);
    }
}

[CustomEditor(typeof(BezierCurve))]
[CanEditMultipleObjects]
public class BezierCurveEditor : Editor {
    public List<BezierCurve> boxes = new List<BezierCurve>();

    public void OnEnable() {
        foreach (var t in targets) {
            if ((BezierCurve)t!=null) boxes.Add((BezierCurve)t);
        }
    }

    public void OnSceneGUI() {
        foreach (BezierCurve box in boxes) {
            if (Event.current.type == EventType.MouseUp) box.Change();
            box.Adjust();
        }
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Reset"))
        {
            foreach (BezierCurve box in boxes) box.Reset();
        }
        DrawDefaultInspector();
    }
}

