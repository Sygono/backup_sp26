using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;

[RequireComponent(typeof(MeshFilter))]
public class SplineMesh : MonoBehaviour
{
    public enum Axis
    {
        X,
        Z
    }

    public BezierCurve spline;
    public Mesh baseMesh;
    public MeshFilter filter;

    public Axis axis;
    [Range(0,1)]
    public float minLength;
    [Range(0,1)]
    public float maxLength = 1;
    [Range(0,1)]
    public float unitLength = 0.2f;
    public bool autoLength;
    public bool flipUnit;
    public float heightScale = 1;
    public float bumb = 1;
    public float heightScaleOffset;
    public float bumbOffset;
    public float rotationOffset;
    public bool flipNormal;
    public bool autoNormal;

    public ComputeShader deformationComputeShader;

    private ComputeBuffer vertexBuffer;
    private ComputeBuffer controlPointsBuffer;

    bool setup;

    void OnValidate() {
        Deform();
    }

    public void Deform()
    {
        //Vector3 savedPosition = transform.position;
        if (baseMesh==null||spline==null||filter==null) {
            return;
        }

        transform.position = Vector3.zero;

        float lmin = Math.Min(maxLength, minLength);
        float lmax = Math.Max(maxLength, minLength);

        float actualLength = lmax - lmin;
        bool xMode = axis==Axis.X; 

        float splineLength = spline.GetLength();
        Debug.Log(splineLength);
        if (autoLength) {
            //float width = xMode?boundsSize.z:boundsSize.x;
            //width *= bump;
            float length = xMode?baseMesh.bounds.size.x:baseMesh.bounds.size.z;
            length *= Math.Abs(bumb);
            unitLength = length/(splineLength*1f);
        }
        unitLength = Math.Min(actualLength, unitLength);

        List<Mesh> meshes = new List<Mesh>();
        float n = lmin;
        while (n<lmax) {
            vertexBuffer = new ComputeBuffer(baseMesh.vertices.Length, sizeof(float) * 3);
            vertexBuffer.SetData(baseMesh.vertices);

            controlPointsBuffer = new ComputeBuffer(spline.controlPoints.Count, sizeof(float) * 3);
            controlPointsBuffer.SetData(spline.controlPoints);

            // Set up compute shader
            int kernelHandle = deformationComputeShader.FindKernel("SplineDeform");
            deformationComputeShader.SetBuffer(kernelHandle, "vertexBuffer", vertexBuffer);
            deformationComputeShader.SetBuffer(kernelHandle, "controlPointsBuffer", controlPointsBuffer);
            deformationComputeShader.SetBool("axis", (int)axis==0);
            deformationComputeShader.SetFloat("start", n);
            deformationComputeShader.SetFloat("end", n+unitLength);
            deformationComputeShader.SetFloat("heightScale", heightScale);
            deformationComputeShader.SetFloat("bumb", bumb);
            deformationComputeShader.SetFloat("heightScaleOffset", heightScaleOffset);
            deformationComputeShader.SetFloat("bumbOffset", bumbOffset);
            deformationComputeShader.SetFloat("rotationOffset", rotationOffset);
            deformationComputeShader.SetBool("axis", (int)axis==0);
            deformationComputeShader.SetBool("autoNormal", autoNormal);
            deformationComputeShader.SetBool("flipUnit", flipUnit);
            deformationComputeShader.SetVector("_BoundsSize", baseMesh.bounds.size);
            deformationComputeShader.SetVector("_BoundsMin", baseMesh.bounds.min);

            // Calculate number of thread groups
            int numGroupsX = Mathf.CeilToInt((float)vertexBuffer.count / 64); // Calculate number of thread groups along the X-axis
            int numGroupsY = 1; // Number of thread groups along the Y-axis
            int numGroupsZ = 1; // Number of thread groups along the Z-axis

            // Dispatch compute shader with adjusted dispatch size
            deformationComputeShader.Dispatch(kernelHandle, numGroupsX, numGroupsY, numGroupsZ);


            // Retrieve deformed vertices
            Vector3[] deformedVertices = new Vector3[vertexBuffer.count];
            vertexBuffer.GetData(deformedVertices);

            // Update mesh

            Mesh m = new Mesh();
            m.vertices = deformedVertices;
            m.triangles = baseMesh.triangles;
            m.uv = baseMesh.uv;
            m.RecalculateNormals();
            m.RecalculateBounds();

            meshes.Add(m);
            n+=unitLength;
            Dispose();
        }

        

        CombineInstance[] combine = new CombineInstance[meshes.Count];

        int i = 0;
        while (i < meshes.Count)
        {
            combine[i].mesh = meshes[i];
            combine[i].transform = transform.localToWorldMatrix;
            i++;
        }

        Mesh new_mesh = new Mesh();
        new_mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        new_mesh.CombineMeshes(combine);
        filter.sharedMesh = new_mesh;
        //filter.sharedMesh.RecalculateNormals();
        filter.sharedMesh.RecalculateBounds();

        Matrix4x4[] matrices = new Matrix4x4[1];
        matrices[0] = transform.localToWorldMatrix;
        foreach (Mesh mesh in meshes) {
            //Graphics.DrawMeshInstanced(mesh, 0, material, matrices, 1);
        }
        transform.position = spline.transform.position;
    }

    public void Dispose()
    {
        if (vertexBuffer != null)
        {
            vertexBuffer.Release();
            vertexBuffer = null;
        }
        if (controlPointsBuffer != null)
        {
            controlPointsBuffer.Release();
            controlPointsBuffer = null;
        }
    }

    void OnDestroy()
    {
        Dispose();
    }

    void OnDrawGizmosSelected() {
        //Deform();
    }

    void OnDrawGizmos() {
        if (spline!=null&&!setup) {
            spline.OnChange.AddListener(Deform);
            setup = true;
        }
    }

}


[CustomEditor(typeof(SplineMesh))]
[CanEditMultipleObjects]
public class SplineMeshEditor : Editor {
    public List<SplineMesh> boxes = new List<SplineMesh>();

    public void OnEnable() {
        foreach (var t in targets) {
            if ((SplineMesh)t!=null) boxes.Add((SplineMesh)t);
        }
    }

    public void OnSceneGUI() {
        foreach (SplineMesh box in boxes) {
            //if (Event.current.type == EventType.MouseUp) box.Deform();
            //box.Adjust();
        }
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Deform"))
        {
            foreach (SplineMesh box in boxes) box.Deform();
        }
        DrawDefaultInspector();
    }
}
