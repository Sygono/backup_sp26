using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SplineDeformerGPU : MonoBehaviour
{
    public enum Axis
    {
        X,
        Z
    }

    public Vector3[] controlPoints;
    public Mesh baseMesh;
    public MeshFilter filter;
    public Material material;

    public Axis axis;
    public float heightScale = 1;
    public float bumb = 1;
    public float rotationOffset;
    public bool flip;
    public bool autoNormal;

    [Range(0,1)]
    public float start;
    [Range(0,1)]
    public float end = 1;
    [Range(0,1)]
    public float unitLength = 0.2f;

    public ComputeShader deformationComputeShader;

    // Compute buffers
    private ComputeBuffer vertexBuffer;
    private ComputeBuffer controlPointsBuffer;

    public void Adjust() {
        for (int i = 0; i < controlPoints.Length; i++) {
            Vector3 v = Handles.FreeMoveHandle(transform.TransformPoint(controlPoints[i]), 0.5f, Vector3.zero, Handles.RectangleHandleCap);
            Vector3 newPos = transform.InverseTransformPoint(v);
            if (newPos != controlPoints[i])
            {
                // Record the object for undo purposes
                Undo.RecordObject(this, "Move Control Point");
                controlPoints[i] = newPos;
                EditorUtility.SetDirty(this);
            }
        }
    }

    void OnValidate() {
        Deform();
    }

    public void Deform()
    {
        List<Mesh> meshes = new List<Mesh>();
        float n = start;
        while (n<end) {
            vertexBuffer = new ComputeBuffer(baseMesh.vertices.Length, sizeof(float) * 3);
            vertexBuffer.SetData(baseMesh.vertices);

            controlPointsBuffer = new ComputeBuffer(controlPoints.Length, sizeof(float) * 3);
            controlPointsBuffer.SetData(controlPoints);

            // Set up compute shader
            int kernelHandle = deformationComputeShader.FindKernel("DeformVertices");
            deformationComputeShader.SetBuffer(kernelHandle, "vertexBuffer", vertexBuffer);
            deformationComputeShader.SetBuffer(kernelHandle, "controlPointsBuffer", controlPointsBuffer);
            deformationComputeShader.SetBool("axis", (int)axis==0);
            deformationComputeShader.SetFloat("start", n);
            deformationComputeShader.SetFloat("end", n+unitLength);
            deformationComputeShader.SetFloat("heightScale", heightScale);
            deformationComputeShader.SetFloat("bumb", bumb);
            deformationComputeShader.SetFloat("rotationOffset", rotationOffset);
            deformationComputeShader.SetBool("axis", (int)axis==0);
            deformationComputeShader.SetBool("flip", flip);
            deformationComputeShader.SetBool("autoNormal", autoNormal);
            deformationComputeShader.SetVector("_BoundsSize", baseMesh.bounds.size);
            deformationComputeShader.SetVector("_BoundsMin", baseMesh.bounds.min);

            // Calculate number of thread groups
            int numGroupsX = Mathf.CeilToInt((float)vertexBuffer.count / 64); // Calculate number of thread groups along the X-axis
            int numGroupsY = 1; // Number of thread groups along the Y-axis
            int numGroupsZ = 1; // Number of thread groups along the Z-axis

            // Dispatch compute shader with adjusted dispatch size
            deformationComputeShader.Dispatch(kernelHandle, numGroupsX, numGroupsY, numGroupsZ);


            // Retrieve deformed vertices
            Vector3[] deformedVertices = new Vector3[vertexBuffer.count];
            vertexBuffer.GetData(deformedVertices);

            // Update mesh

            Mesh m = new Mesh();
            m.vertices = deformedVertices;
            m.triangles = baseMesh.triangles;
            m.uv = baseMesh.uv;
            m.RecalculateNormals();
            m.RecalculateBounds();

            meshes.Add(m);
            Dispose();

            n+=unitLength;
        }

        CombineInstance[] combine = new CombineInstance[meshes.Count];

        int i = 0;
        while (i < meshes.Count)
        {
            combine[i].mesh = meshes[i];
            combine[i].transform = transform.localToWorldMatrix;
            i++;
        }

        Mesh new_mesh = new Mesh();
        new_mesh.CombineMeshes(combine);
        filter.sharedMesh = new_mesh;
        filter.sharedMesh.RecalculateNormals();
        filter.sharedMesh.RecalculateBounds();

        Matrix4x4[] matrices = new Matrix4x4[1];
        matrices[0] = transform.localToWorldMatrix;
        foreach (Mesh mesh in meshes) {
            //Graphics.DrawMeshInstanced(mesh, 0, material, matrices, 1);
        }

    }

    public void Dispose()
    {
        if (vertexBuffer != null)
        {
            vertexBuffer.Release();
            vertexBuffer = null;
        }
        if (controlPointsBuffer != null)
        {
            controlPointsBuffer.Release();
            controlPointsBuffer = null;
        }
    }

    void OnDestroy()
    {
        Dispose();
    }
}

[CustomEditor(typeof(SplineDeformerGPU))]
[CanEditMultipleObjects]
public class SplineDeformerGPUEditor : Editor {
    public List<SplineDeformerGPU> boxes = new List<SplineDeformerGPU>();

    public void OnEnable() {
        foreach (var t in targets) {
            if ((SplineDeformerGPU)t!=null) boxes.Add((SplineDeformerGPU)t);
        }
    }

    public void OnSceneGUI() {
        foreach (SplineDeformerGPU box in boxes) {
            if (Event.current.type == EventType.MouseUp) box.Deform();
            box.Adjust();
        }
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Deform"))
        {
            foreach (SplineDeformerGPU box in boxes) box.Deform();
        }
        DrawDefaultInspector();
    }
}
