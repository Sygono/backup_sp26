using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SplineDeformer : MonoBehaviour
{
    public enum Axis {
        X,
        Z
    }
    
    public Mesh baseMesh;
    public MeshFilter filter;
    public BezierCurve spline;

    public Axis axis;
    public float heightScale = 1;
    public float bumb = 1;
    public float rotationOffset;
    public bool flip;
    public bool vertexMode;
    public bool autoNormal;

    public void Deform()
    {
     
        //if (filter.sharedMesh == null) return;
        filter.sharedMesh = new Mesh();
        Vector3[] verts = baseMesh.vertices;
        for (int i = 0; i < verts.Length; i++)
        {
            float sVal = GetSplineValue(verts[i]);
            Debug.Log(sVal);
            (Vector3 splinePoint, Vector3 dir) = SplineNormal(sVal);

            Vector3 normal = Vector3.Cross(dir, Vector3.up);

            float angle = rotationOffset;
            float cosTheta = Mathf.Cos(angle * Mathf.Deg2Rad);
            float sinTheta = Mathf.Sin(angle * Mathf.Deg2Rad);
            normal = normal * cosTheta + Vector3.Cross(dir, normal) * sinTheta + dir * Vector3.Dot(dir, normal) * (1 - cosTheta);

            Vector3 up = autoNormal?Vector3.Cross(normal, dir):Vector3.up;
            float offset = axis==Axis.X? verts[i].z : verts[i].x;

            if (flip)
            {
                normal *= -1;
            }

            verts[i] = normal * bumb * offset + splinePoint + verts[i].y * heightScale * up;
        }
        filter.sharedMesh.vertices = verts;
        filter.sharedMesh.triangles = baseMesh.triangles;
        filter.sharedMesh.uv = baseMesh.uv;
        filter.sharedMesh.RecalculateNormals();
        filter.sharedMesh.RecalculateBounds();
    }

    Quaternion GetRotation(float t) {
        return Quaternion.identity;
    }

    float GetSplineValue(Vector3 position)
    {
        if (axis == Axis.X)
        {
            float min = baseMesh.bounds.min.x;
            float length = baseMesh.bounds.size.x;
            return (position.x - min) / length;
        }
        else
        {
            float min = baseMesh.bounds.min.z;
            float length = baseMesh.bounds.size.z;
            return (position.z - min) / length;
        }
    }

    (Vector3, Vector3) SplineNormal(float val)
    {
        Vector3 point, dir;
        if (!vertexMode) {
            (point, dir) = spline.Evaluate(val);
        } else {
            (point, dir) = spline.GetValue(val);
        }
        return (point,dir);
    }

    void Update() {
        Deform();
    }
}

[CustomEditor(typeof(SplineDeformer))]
[CanEditMultipleObjects]
public class SplineDeformerEditor : Editor {
    public List<SplineDeformer> boxes = new List<SplineDeformer>();

    public void OnEnable() {
        foreach (var t in targets) {
            if ((SplineDeformer)t!=null) boxes.Add((SplineDeformer)t);
        }
    }

    public void OnSceneGUI() {
        foreach (SplineDeformer box in boxes) {
            //if (Event.current.type == EventType.MouseUp) box.AdjustRotation();
            //box.Adjust();
        }
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Deform"))
        {
            foreach (SplineDeformer box in boxes) box.Deform();
        }
        DrawDefaultInspector();
    }
}
