using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;



[Serializable]
public class NestedList<T>
{
    [SerializeField]
    public List<T> subValue = new List<T>();

    public int Count => subValue.Count;

    public T this[int index]
    {
        get
        {
            return subValue[index];
        }
        set
        {
            subValue[index] = value;
        }
    }

    public void Add(T item) {
        subValue.Add(item);
    }
}




public class BezierPatch : MonoBehaviour
{
    [SerializeField]
    private List<NestedList<Vector3>> nestedList;
    List<List<Vector3>> controlPoints;

    [Range(1,32)]
    public int steps;
    public bool smoothShading;
    public Material material;

    public float controlPointRadius = 0.1f;

    Mesh mesh;


    void SetControlPoints() {
        if (nestedList.Count<4||nestedList[0].Count<4) return;
        Reset();
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                controlPoints[i][j] = nestedList[i][j];
            }
        }
    }

    public void Adjust() {
        controlPoints = new List<List<Vector3>>(4);
        for (int i = 0; i < 4; i++)
        {
            controlPoints.Add(new List<Vector3>(4));
            for (int j = 0; j < 4; j++)
            {
                controlPoints[i].Add(Vector3.zero);
            }
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                Vector3 v = Handles.FreeMoveHandle(transform.TransformPoint(nestedList[i][j]), 0.5f, Vector3.zero, Handles.RectangleHandleCap);
                Vector3 newPos = transform.InverseTransformPoint(v);
                if (newPos != controlPoints[i][j])
                {
                    // Record the object for undo purposes
                    Undo.RecordObject(this, "Move Control Point");

                    // Update the position of the object
                    nestedList[i][j] = newPos;
                    controlPoints[i][j] = newPos;

                    // Mark the object as dirty so changes are saved
                    EditorUtility.SetDirty(this);
                }
            }
        }
    }

    public void Reset()
    {
        nestedList = new List<NestedList<Vector3>>(4);
        for (int i = 0; i < 4; i++)
        {
            nestedList.Add(new NestedList<Vector3>());
            for (int j = 0; j < 4; j++)
            {
                nestedList[i].Add(new Vector3(i, 0, j));
            }
        }
    }

    void Render() {
        mesh = new Mesh();
        int nu = steps;
        int nv = steps;
        List<Vector3> vertices = new List<Vector3>();
        List<int> triangles = new List<int>();
        List<Vector3> normals = new List<Vector3>();
        List<Vector2> uvs = new List<Vector2>();

        for (int i = 0; i < nu; i++)
        {
            for (int j = 0; j < nv; j++)
            {
                Vector2 u0, u1, u2, u3;
                u0 = new Vector2(i / (float)nu, j / (float)nv);
                u1 = new Vector2((i + 1) / (float)nu, j / (float)nv);
                u2 = new Vector2((i + 1) / (float)nu, (j + 1) / (float)nv);
                u3 = new Vector2(i / (float)nu, (j + 1) / (float)nv);


                Vector3 v0, v1, v2, v3;
                Vector3 n0, n1, n2, n3;
                (v0, n0) = Evaluate(u0);
                (v1, n1) = Evaluate(u1);
                (v2, n2) = Evaluate(u2);
                (v3, n3) = Evaluate(u3);

                int baseIndex = vertices.Count;
                vertices.Add(v0);
                vertices.Add(v1);
                vertices.Add(v2);
                vertices.Add(v3);

                normals.Add(n0);
                normals.Add(n1);
                normals.Add(n2);
                normals.Add(n3);

                triangles.Add(baseIndex);
                triangles.Add(baseIndex + 1);
                triangles.Add(baseIndex + 2);
                triangles.Add(baseIndex);
                triangles.Add(baseIndex + 2);
                triangles.Add(baseIndex + 3);

                uvs.Add(u0);
                uvs.Add(u1);
                uvs.Add(u2);
                uvs.Add(u3);
            }
        }

        mesh.vertices = vertices.ToArray();
        mesh.triangles = triangles.ToArray();
        if (smoothShading) {
            mesh.normals = normals.ToArray();
        } else {
            mesh.RecalculateNormals();
        }
        mesh.uv = uvs.ToArray();
        mesh.RecalculateBounds();

    }   

    // Modify the signature of the method to use ref
    void EvaluateStep(ref List<Vector3> points, float t)
    {
        int n = points.Count;
        if (n == 1)
        {
            return;
        }

        List<Vector3> lerps = new List<Vector3>();
        for (int i = 0; i < n - 1; i++)
        {
            lerps.Add((1.0f - t) * points[i] + t * points[i + 1]);
        }

        // Update the original points list
        points = lerps;
    }

    public (Vector3, Vector3) Evaluate1D(List<Vector3> points, float t)
    {
        List<List<Vector3>> evaluatedLevels = new List<List<Vector3>>();
        evaluatedLevels.Add(points);
        for (int i = 0; i <= points.Count; i++)
        {
            EvaluateStep(ref points, t);
            evaluatedLevels.Add(points);
        }
        List<Vector3> lastLevel = evaluatedLevels[evaluatedLevels.Count - 1];
        List<Vector3> tangentLevel = evaluatedLevels[evaluatedLevels.Count - 2];
        return (lastLevel[0], (tangentLevel[1] - tangentLevel[0]).normalized);
    }

    public (Vector3, Vector3) Evaluate(Vector2 t)
    {
        List<Vector3> points = new List<Vector3>();
        for (int i = 0; i < controlPoints.Count; i++)
        {
            List<Vector3> row = new List<Vector3>(controlPoints[i]);
            while (row.Count!=1) {
                EvaluateStep(ref row, t.x);
            }
            points.Add(row[0]);
        }
        //Debug.Log(points.Count);
        (var point, var dir) = Evaluate1D(points, t.y);
        var normal = Vector3.Cross(dir, Vector3.up);
        var up = Vector3.Cross(normal, dir);
        return (point, up);
    }

    public (Vector3, Vector3) GetValue(Vector2 t) {
        int i = (int)Mathf.Round(t.x*(steps-1));
        int j = (int)Mathf.Round(t.y*(steps-1));
        int index = j*steps+i;
        return (mesh.vertices[index], mesh.normals[index]);
    }

    void OnDrawGizmosSelected() {
        if (controlPoints==null) return;
        if (controlPoints.Count==0) return;

        Render(); 
    }

    void OnDrawGizmos()
    {
        if (controlPoints==null) return;
        if (controlPoints.Count==0) return;

        
        Gizmos.color = Color.red;
        foreach (var row in controlPoints)
        {
            foreach (var point in row)
            {
                Gizmos.DrawSphere(transform.TransformPoint(point), controlPointRadius);
            }
        }

        Gizmos.color = Color.green;
        Vector3[] vertices = mesh.vertices;
        int[] triangles = mesh.triangles;

        for (int i = 0; i < triangles.Length; i += 3)
        {
            Vector3 v0 = vertices[triangles[i]];
            Vector3 v1 = vertices[triangles[i + 1]];
            Vector3 v2 = vertices[triangles[i + 2]];

            Gizmos.DrawLine(transform.TransformPoint(v0), transform.TransformPoint(v1));
            Gizmos.DrawLine(transform.TransformPoint(v1), transform.TransformPoint(v2));
            Gizmos.DrawLine(transform.TransformPoint(v2), transform.TransformPoint(v0));
        }
    }
}

[CustomEditor(typeof(BezierPatch))]
[CanEditMultipleObjects]
public class BezierPatchEditor : Editor {
    public List<BezierPatch> boxes = new List<BezierPatch>();

    public void OnEnable() {
        foreach (var t in targets) {
            if ((BezierPatch)t!=null) boxes.Add((BezierPatch)t);
        }
    }

    public void OnSceneGUI() {
        foreach (BezierPatch box in boxes) {
            //if (Event.current.type == EventType.MouseUp) box.AdjustRotation();
            box.Adjust();
        }
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Reset"))
        {
            foreach (BezierPatch box in boxes) box.Reset();
        }
        DrawDefaultInspector();
    }
}
