using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class PatchDeformer : MonoBehaviour
{
    
    public Mesh baseMesh;
    public MeshFilter filter;
    public BezierPatch patch;

    public float heightScale = 1;
    public bool vertexMode;
    public bool autoNormal;

    public void Deform()
    {
     
        //if (filter.sharedMesh == null) return;
        filter.sharedMesh = new Mesh();
        Vector3[] verts = baseMesh.vertices;
        for (int i = 0; i < verts.Length; i++)
        {
            var pVal = GetPatchValue(verts[i]);
            (Vector3 point, Vector3 up) = PatchNormal(pVal);
            verts[i] = point + verts[i].y * heightScale * up * -1;
        }
        filter.sharedMesh.vertices = verts;
        filter.sharedMesh.triangles = baseMesh.triangles;
        filter.sharedMesh.uv = baseMesh.uv;
        filter.sharedMesh.RecalculateNormals();
        filter.sharedMesh.RecalculateBounds();
    }

    Vector2 GetPatchValue(Vector3 position)
    {
        float minX = baseMesh.bounds.min.x;
        float lengthX = baseMesh.bounds.size.x;
        float minZ = baseMesh.bounds.min.z;
        float lengthZ = baseMesh.bounds.size.z;
        return new Vector2 ((position.x - minX) / lengthX, (position.z - minZ) / lengthZ);
    }

    (Vector3, Vector3) PatchNormal(Vector2 val)
    {
        Vector3 point, up;
        if (!vertexMode) {
            (point, up) = patch.Evaluate(val);
        } else {
            (point, up) = patch.GetValue(val);
        }
        return (point,up);
    }

    void OnDrawGizmosSelected() {
        Deform();
    }
}

[CustomEditor(typeof(PatchDeformer))]
[CanEditMultipleObjects]
public class PatchDeformerEditor : Editor {
    public List<PatchDeformer> boxes = new List<PatchDeformer>();

    public void OnEnable() {
        foreach (var t in targets) {
            if ((PatchDeformer)t!=null) boxes.Add((PatchDeformer)t);
        }
    }

    public void OnSceneGUI() {
        foreach (PatchDeformer box in boxes) {
            //if (Event.current.type == EventType.MouseUp) box.AdjustRotation();
            //box.Adjust();
        }
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Deform"))
        {
            foreach (PatchDeformer box in boxes) box.Deform();
        }
        DrawDefaultInspector();
    }
}
