using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]
public class MeshControl : MonoBehaviour
{
    public enum ControlMode {
        Linear,
        BezierCurve,
        BezierPatch
    }

    public ControlMode mode;

    public enum Axis
    {
        X,
        Z
    }

    public BezierCurve spline;
    public BezierPatch patch;
    public Mesh baseMesh;
    public MeshFilter filter;

    public Axis axis;
    [Range(0,1)]
    public float minLength;
    [Range(0,1)]
    public float maxLength = 1;
    [Range(0,1)]
    public float unitLength = 0.2f;
    public bool autoLength;
    public bool flipUnit;
    public float heightScale = 1;
    public float bumb = 1;
    public float heightScaleOffset;
    public float bumbOffset;
    public float rotationOffset;
    public bool flipNormal;
    public bool autoNormal;

    public ComputeShader deformationComputeShader;
    private ComputeBuffer vertexBuffer;
    private ComputeBuffer controlPointsBuffer;

    bool setup;

    public void Deform() {
        if (baseMesh==null||spline==null||filter==null) {
            return;
        }

        transform.position = Vector3.zero;

        float lmin = Math.Min(maxLength, minLength);
        float lmax = Math.Max(maxLength, minLength);

        float actualLength = lmax - lmin;
        bool xMode = axis==Axis.X; 
        
        float splineLength = spline.GetLength();
        if (mode==ControlMode.Linear) {
            splineLength = Vector3.Distance(spline.controlPoints[spline.controlPoints.Count-1], spline.controlPoints[0]);
        }

        float stepLength;
        Debug.Log(splineLength);
        if (autoLength) {
            //float width = xMode?boundsSize.z:boundsSize.x;
            //width *= bump;
            float length = xMode?baseMesh.bounds.size.x:baseMesh.bounds.size.z;
            length *= Math.Abs(bumb);
            unitLength = length/(splineLength*1f);
        }
        stepLength = Math.Min(actualLength, unitLength);
        if (stepLength==0) return;

        int bufferSize;
        string kernelName;
        if (mode==ControlMode.Linear) {
            bufferSize = 2;
            kernelName = "LinearDeform";
        } else if (mode==ControlMode.BezierCurve) {
            bufferSize = 4;
            kernelName = "SplineDeform";
        } else {
            bufferSize = 16;
            kernelName = "PatchDeform";
        }

        List<Mesh> meshes = new List<Mesh>();
        float n = lmin;
        while (n<lmax) {
            vertexBuffer = new ComputeBuffer(baseMesh.vertices.Length, sizeof(float) * 3);
            vertexBuffer.SetData(baseMesh.vertices);

            controlPointsBuffer = new ComputeBuffer(bufferSize, sizeof(float) * 3);

            List<Vector3> data = new List<Vector3>();
            if (mode==ControlMode.Linear) {
                data.Add(spline.controlPoints[0]);
                data.Add(spline.controlPoints[spline.controlPoints.Count-1]);
            } else if (mode==ControlMode.BezierCurve) {
                data = spline.controlPoints;
            } else {

            }
            controlPointsBuffer.SetData(data);

            // Set up compute shader
            int kernelHandle = deformationComputeShader.FindKernel(kernelName);
            deformationComputeShader.SetBuffer(kernelHandle, "vertexBuffer", vertexBuffer);
            deformationComputeShader.SetBuffer(kernelHandle, "controlPointsBuffer", controlPointsBuffer);
            deformationComputeShader.SetBool("axis", (int)axis==0);
            deformationComputeShader.SetFloat("start", n);
            deformationComputeShader.SetFloat("end", Math.Min(lmax,n+stepLength));
            deformationComputeShader.SetFloat("heightScale", heightScale);
            deformationComputeShader.SetFloat("bumb", bumb);
            deformationComputeShader.SetFloat("heightScaleOffset", heightScaleOffset);
            deformationComputeShader.SetFloat("bumbOffset", bumbOffset);
            deformationComputeShader.SetFloat("rotationOffset", rotationOffset);
            deformationComputeShader.SetBool("axis", (int)axis==0);
            deformationComputeShader.SetBool("autoNormal", autoNormal);
            deformationComputeShader.SetBool("flipUnit", flipUnit);
            deformationComputeShader.SetVector("_BoundsSize", baseMesh.bounds.size);
            deformationComputeShader.SetVector("_BoundsMin", baseMesh.bounds.min);

            // Calculate number of thread groups
            int numGroupsX = Mathf.CeilToInt((float)vertexBuffer.count / 64); // Calculate number of thread groups along the X-axis
            int numGroupsY = 1; // Number of thread groups along the Y-axis
            int numGroupsZ = 1; // Number of thread groups along the Z-axis

            // Dispatch compute shader with adjusted dispatch size
            deformationComputeShader.Dispatch(kernelHandle, numGroupsX, numGroupsY, numGroupsZ);


            // Retrieve deformed vertices
            Vector3[] deformedVertices = new Vector3[vertexBuffer.count];
            vertexBuffer.GetData(deformedVertices);

            // Update mesh

            Mesh m = new Mesh();
            m.vertices = deformedVertices;
            m.triangles = baseMesh.triangles;
            m.uv = baseMesh.uv;
            m.RecalculateNormals();
            m.RecalculateBounds();

            meshes.Add(m);
            n+=stepLength;
            Dispose();
        }

        CombineInstance[] combine = new CombineInstance[meshes.Count];

        int i = 0;
        while (i < meshes.Count)
        {
            combine[i].mesh = meshes[i];
            combine[i].transform = transform.localToWorldMatrix;
            i++;
        }

        Mesh new_mesh = new Mesh();
        new_mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        new_mesh.CombineMeshes(combine);
        filter.sharedMesh = new_mesh;
        filter.sharedMesh.RecalculateBounds();
        Matrix4x4[] matrices = new Matrix4x4[1];
        matrices[0] = transform.localToWorldMatrix;
        foreach (Mesh mesh in meshes) {
            //Graphics.DrawMeshInstanced(mesh, 0, material, matrices, 1);
        }
        transform.position = spline.transform.position;
    }

    public void Dispose()
    {
        if (vertexBuffer != null)
        {
            vertexBuffer.Release();
            vertexBuffer = null;
        }
        if (controlPointsBuffer != null)
        {
            controlPointsBuffer.Release();
            controlPointsBuffer = null;
        }
    }

    void OnValidate() {
        Deform();
    }

    void OnDrawGizmos() {
        if (spline!=null&&!setup) {
            Reset();
        }
    }

    public void Reset() {
        spline.OnChange.AddListener(Deform);
        setup = true;
    }
}

[CustomEditor(typeof(MeshControl))]
[CanEditMultipleObjects]
public class MeshControlEditor : Editor {
    public List<MeshControl> boxes = new List<MeshControl>();

    public void OnEnable() {
        foreach (var t in targets) {
            if ((MeshControl)t!=null) boxes.Add((MeshControl)t);
        }
    }

    public void OnSceneGUI() {
        foreach (MeshControl box in boxes) {
            //if (Event.current.type == EventType.MouseUp) box.AdjustRotation();
            //box.Adjust();
        }
    }

    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Reset"))
        {
            foreach (MeshControl box in boxes) box.Reset();
        }
        DrawDefaultInspector();
    }
}
