using MathNet.Numerics.LinearAlgebra;
using System;
using System.Linq;
using Unity.Mathematics;
using UnityEngine;

public static class Utils
{
    // public static void FitPlane(Vector3[] points, out Vector3 center, out Vector3 normal)
    // {
    //     if (points == null || points.Length < 3)
    //     {
    //         center = Vector3.zero;
    //         normal = Vector3.up;
    //         Debug.LogWarning("At least 3 points are required to fit a plane.");
    //         return;
    //     }

    //     // Convert to float3
    //     float3[] floatPoints = new float3[points.Length];
    //     for (int i = 0; i < points.Length; i++)
    //         floatPoints[i] = points[i];

    //     // Compute centroid
    //     float3 centroid = float3.zero;
    //     foreach (var p in floatPoints)
    //         centroid += p;
    //     centroid /= floatPoints.Length;

    //     // Compute covariance matrix
    //     float3x3 cov = float3x3.zero;
    //     foreach (var p in floatPoints)
    //     {
    //         float3 r = p - centroid;
    //         cov.c0 += r * r.x;
    //         cov.c1 += r * r.y;
    //         cov.c2 += r * r.z;
    //     }

    //     // Compute SVD
    //     math.svd(cov, out float3x3 U, out float3 _, out float3x3 _);

    //     float3 planeNormal = U.c2; // Column with smallest singular value

    //     center = centroid;
    //     normal = math.normalize(planeNormal);
    // }

    public static void FitPlane(Vector3[] points, out Vector3 center, out Vector3 normal)
    {
        int n = points.Length;
        if (n < 2)
        {
            center = Vector3.zero;
            normal = Vector3.up;
            Debug.LogWarning("Need at least 2 points.");
            return;
        }

        if (n == 2)
        {
            center = (points[0] + points[1]) / 2;
            var linearNormal = (points[1] - points[0]).normalized;
            var axis = Vector3.Cross(Vector3.up, linearNormal);
            var angle = Vector3.Angle(Vector3.up, linearNormal);
            normal = Quaternion.AngleAxis(angle - 90f, axis) * Vector3.up;
            return;
        }

        // Compute centroid
        center = Vector3.zero;
        foreach (var p in points) center += p;
        center /= n;

        // Build centered matrix A (n × 3)
        var A = Matrix<double>.Build.Dense(n, 3);
        for (int i = 0; i < n; i++)
        {
            Vector3 r = points[i] - center;
            A[i, 0] = r.x;
            A[i, 1] = r.y;
            A[i, 2] = r.z;
        }

        // SVD of A
        var svd = A.Svd(computeVectors: true);
        // Normal is the last column of V (corresponding to smallest singular value)
        var v = svd.VT.Transpose();
        normal = new Vector3((float)v[0, 2], (float)v[1, 2], (float)v[2, 2]).normalized;
    }

    public static Vector3 LinePlaneIntersection(Vector3 origin, Vector3 direction, Vector3 point, Vector3 normal) {
        float denom = Vector3.Dot(direction, normal);
        float t = Vector3.Dot(point - origin, normal) / denom;
        return origin + direction * t;
    }

    public static void ApplySpringForce(Rigidbody body, Vector3 target, float k, float damping)
    {
        // Displacement from target
        Vector3 displacement = target - body.position;

        // Spring force: F = k * displacement
        Vector3 springForce = displacement * k;

        // Damping force: F = -damping * velocity
        Vector3 dampingForce = -body.linearVelocity * damping;

        // Total force
        Vector3 force = springForce + dampingForce;

        // Apply the force
        body.AddForce(force, ForceMode.Acceleration);
    }
}

public static class TargetInfoExtensions
{
    /// <summary>
    /// Transforms TargetInfo from local space to world space.
    /// </summary>
    public static TargetInfo TransformTargetInfo(this Transform t, TargetInfo local)
    {
        return new TargetInfo
        {
            point  = t.TransformPoint(local.point),
            normal = t.TransformDirection(local.normal).normalized
        };
    }

    /// <summary>
    /// Transforms TargetInfo from world space to local space.
    /// </summary>
    public static TargetInfo InverseTransformTargetInfo(this Transform t, TargetInfo world)
    {
        return new TargetInfo
        {
            point  = t.InverseTransformPoint(world.point),
            normal = t.InverseTransformDirection(world.normal).normalized
        };
    }
}
