using UnityEngine;

public class SpringToPosition : MonoBehaviour
{
    public Rigidbody rb;
    // public Vector3 targetPosition;
    public Transform targetTransform;
    public float jumpForce = 100f;      // Force applied when jumping
    public float springStrength = 50f;  // Controls how strong the spring pulls
    public float damping = 5f;          // Controls how much velocity is reduced
    private InputSystem_Actions inputActions;
    private Vector2 nativeMoveInput = Vector2.zero;
    private bool jumpPressed = false;

    void Awake()
    {
        inputActions = new InputSystem_Actions();
        inputActions.Player.Move.performed += ctx => nativeMoveInput = ctx.ReadValue<Vector2>();
        inputActions.Player.Move.canceled += _ => nativeMoveInput = Vector2.zero;
    }

    private void OnEnable() => inputActions.Enable();
    private void OnDisable() => inputActions.Disable();


    void FixedUpdate()
    {
        jumpPressed = inputActions.Player.Jump.triggered;
        if (jumpPressed)
        {
            Debug.Log("Jump pressed, applying force.");
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
        ApplySpringForce(rb, targetTransform.position, springStrength, damping);
    }

    void ApplySpringForce(Rigidbody body, Vector3 target, float k, float damping)
    {
        // Displacement from target
        Vector3 displacement = target - body.position;

        // Spring force: F = k * displacement
        Vector3 springForce = displacement * k;

        // Damping force: F = -damping * velocity
        Vector3 dampingForce = -body.linearVelocity * damping;

        // Total force
        Vector3 force = springForce + dampingForce;

        // Apply the force
        body.AddForce(force, ForceMode.Acceleration);
    }
}
