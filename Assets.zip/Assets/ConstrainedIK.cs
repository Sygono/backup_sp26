using UnityEngine;
using Unity.Collections;
using Unity.Burst;

namespace UnityEngine.Animations.Rigging
{
    [System.Serializable]
    public struct ConstrainedIKData : IAnimationJobData, IConstrainedIKData
    {
        internal const int k_MinIterations = 1;
        internal const int k_MaxIterations = 50;
        internal const float k_MinTolerance = 0f;
        internal const float k_MaxTolerance = 0.01f;

        [SerializeField, SyncSceneToStream] Transform m_Root;
        [SerializeField, SyncSceneToStream] Transform m_Tip;
        [SerializeField, SyncSceneToStream] Transform m_baseTrans;

        [SyncSceneToStream, SerializeField] Transform m_Target;
        [SyncSceneToStream, SerializeField, Range(0f, 1f)] float m_ChainRotationWeight;
        [SyncSceneToStream, SerializeField, Range(0f, 1f)] float m_TipRotationWeight;

        [NotKeyable, SerializeField, Range(k_MinIterations, k_MaxIterations)] int m_MaxIterations;
        [NotKeyable, SerializeField, Range(k_MinTolerance, k_MaxTolerance)] float m_Tolerance;
        [NotKeyable, SerializeField] bool m_MaintainTargetPositionOffset;
        [NotKeyable, SerializeField] bool m_MaintainTargetRotationOffset;

        /// <inheritdoc />
        public Transform root { get => m_Root; set => m_Root = value; }
        /// <inheritdoc />
        public Transform tip { get => m_Tip; set => m_Tip = value; }

        public Transform baseTrans { get => m_baseTrans; set => m_baseTrans = value; }

        /// <inheritdoc />
        public Transform target { get => m_Target; set => m_Target = value; }
        /// <summary>The weight for which ChainIK target has an effect on chain (up to tip Transform). This is a value in between 0 and 1.</summary>
        public float chainRotationWeight { get => m_ChainRotationWeight; set => m_ChainRotationWeight = Mathf.Clamp01(value); }
        /// <summary>The weight for which ChainIK target has and effect on tip Transform. This is a value in between 0 and 1.</summary>
        public float tipRotationWeight { get => m_TipRotationWeight; set => m_TipRotationWeight = Mathf.Clamp01(value); }
        /// <inheritdoc />
        public int maxIterations { get => m_MaxIterations; set => m_MaxIterations = Mathf.Clamp(value, k_MinIterations, k_MaxIterations); }
        /// <inheritdoc />
        public float tolerance { get => m_Tolerance; set => m_Tolerance = Mathf.Clamp(value, k_MinTolerance, k_MaxTolerance); }
        /// <inheritdoc />
        public bool maintainTargetPositionOffset { get => m_MaintainTargetPositionOffset; set => m_MaintainTargetPositionOffset = value; }
        /// <inheritdoc />
        public bool maintainTargetRotationOffset { get => m_MaintainTargetRotationOffset; set => m_MaintainTargetRotationOffset = value; }

        /// <inheritdoc />
        string IConstrainedIKData.chainRotationWeightFloatProperty => ConstraintsUtils.ConstructConstraintDataPropertyName(nameof(m_ChainRotationWeight));
        /// <inheritdoc />
        string IConstrainedIKData.tipRotationWeightFloatProperty => ConstraintsUtils.ConstructConstraintDataPropertyName(nameof(m_TipRotationWeight));

        /// <inheritdoc />
        bool IAnimationJobData.IsValid()
        {
            if (m_Root == null || m_Tip == null || m_Target == null || m_baseTrans == null)
                return false;

            int count = 1;
            Transform tmp = m_Tip;
            while (tmp != null && tmp != m_Root)
            {
                tmp = tmp.parent;
                ++count;
            }

            return (tmp == m_Root && count > 2);
        }

        /// <inheritdoc />
        void IAnimationJobData.SetDefaultValues()
        {
            m_Root = null;
            m_Tip = null;
            m_Target = null;
            m_baseTrans = null;
            m_ChainRotationWeight = 1f;
            m_TipRotationWeight = 1f;
            m_MaxIterations = 15;
            m_Tolerance = 0.0001f;
            m_MaintainTargetPositionOffset = false;
            m_MaintainTargetRotationOffset = false;
        }
    }

    /// <summary>
    /// ChainIK constraint
    /// </summary>
    [DisallowMultipleComponent, AddComponentMenu("Animation Rigging/Custom Constrained IK")]
    public class ConstrainedIK : RigConstraint<
        ConstrainedIKJob,
        ConstrainedIKData,
        ConstrainedIKJobBinder<ConstrainedIKData>
        >
    {
        /// <inheritdoc />
        protected override void OnValidate()
        {
            base.OnValidate();
            m_Data.chainRotationWeight = Mathf.Clamp01(m_Data.chainRotationWeight);
            m_Data.tipRotationWeight = Mathf.Clamp01(m_Data.tipRotationWeight);
            m_Data.maxIterations = Mathf.Clamp(
                m_Data.maxIterations, ConstrainedIKData.k_MinIterations, ConstrainedIKData.k_MaxIterations
            );
            m_Data.tolerance = Mathf.Clamp(
                m_Data.tolerance, ConstrainedIKData.k_MinTolerance, ConstrainedIKData.k_MaxTolerance
            );
        }
    }

    [BurstCompile]
    public struct ConstrainedIKJob : IWeightedAnimationJob
    {
        /// <summary>An array of Transform handles that represents the Transform chain.</summary>
        public NativeArray<ReadWriteTransformHandle> chain;
        /// <summary>The Transform handle for the target Transform.</summary>
        public ReadOnlyTransformHandle target;

        /// <summary>The offset applied to the target transform if maintainTargetPositionOffset or maintainTargetRotationOffset is enabled.</summary>
        public AffineTransform targetOffset;

        public ReadOnlyTransformHandle baseTrans;

        /// <summary>An array of length in between Transforms in the chain.</summary>
        public NativeArray<float> linkLengths;

        /// <summary>An array of positions for Transforms in the chain.</summary>
        public NativeArray<Vector3> linkPositions;

        public NativeArray<Vector3> linkDirections;

        public NativeArray<Quaternion> linkRotations;

        public NativeArray<JointProperties> linkProperties;

        /// <summary>The weight for which ChainIK target has an effect on chain (up to tip Transform). This is a value in between 0 and 1.</summary>
        public FloatProperty chainRotationWeight;
        /// <summary>The weight for which ChainIK target has and effect on tip Transform. This is a value in between 0 and 1.</summary>
        public FloatProperty tipRotationWeight;

        /// <summary>CacheIndex to ChainIK tolerance value.</summary>
        /// <seealso cref="AnimationJobCache"/>
        public CacheIndex toleranceIdx;
        /// <summary>CacheIndex to ChainIK maxIterations value.</summary>
        /// <seealso cref="AnimationJobCache"/>
        public CacheIndex maxIterationsIdx;
        /// <summary>Cache for static properties in the job.</summary>
        public AnimationJobCache cache;

        /// <summary>The maximum distance the Transform chain can reach.</summary>
        public float maxReach;

        /// <inheritdoc />
        public FloatProperty jobWeight { get; set; }

        /// <summary>
        /// Defines what to do when processing the root motion.
        /// </summary>
        /// <param name="stream">The animation stream to work on.</param>
        public void ProcessRootMotion(AnimationStream stream) { }

        /// <summary>
        /// Defines what to do when processing the animation.
        /// </summary>
        /// <param name="stream">The animation stream to work on.</param>
        public void ProcessAnimation(AnimationStream stream)
        {
            float w = jobWeight.Get(stream);
            if (w > 0f)
            {
                linkPositions[0] = chain[0].GetPosition(stream);
                linkRotations[0] = baseTrans.GetRotation(stream);
                for (int i = 1; i < chain.Length; ++i)
                {
                    linkPositions[i] = chain[i].GetPosition(stream);
                    linkRotations[i] = chain[i - 1].GetRotation(stream);
                }

                int tipIndex = chain.Length - 1;
                // if (MyAnimationRuntimeUtils.SolveFABRIK(ref linkPositions, ref linkLengths, ref linkDirections, ref linkRotations, ref linkProperties, target.GetPosition(stream) + targetOffset.translation,
                //     cache.GetRaw(toleranceIdx), maxReach, (int)cache.GetRaw(maxIterationsIdx)))
                if (MyAnimationRuntimeUtils.SolveCCDIK(ref linkPositions, ref linkRotations, ref linkProperties, target.GetPosition(stream) + targetOffset.translation,
                    cache.GetRaw(toleranceIdx), maxReach, (int)cache.GetRaw(maxIterationsIdx)))
                {
                    var chainRWeight = chainRotationWeight.Get(stream) * w;
                    for (int i = 0; i < tipIndex; ++i)
                    {
                        var rot = chain[i].GetRotation(stream);
                        var newRot = linkRotations[i+1];
                        chain[i].SetRotation(stream, Quaternion.Lerp(rot, newRot, chainRWeight));
                    }
                }
                

                chain[tipIndex].SetRotation(
                    stream,
                    Quaternion.Lerp(
                        chain[tipIndex].GetRotation(stream),
                        target.GetRotation(stream) * targetOffset.rotation,
                        tipRotationWeight.Get(stream) * w
                        )
                    );
            }
            else
            {
                for (int i = 0; i < chain.Length; ++i)
                    AnimationRuntimeUtils.PassThrough(stream, chain[i]);
            }
        }
    }
    
    public interface IConstrainedIKData
    {
        /// <summary>The root Transform of the ChainIK hierarchy.</summary>
        Transform root { get; }
        /// <summary>The tip Transform of the ChainIK hierarchy. The tip needs to be a descendant/child of the root Transform.</summary>
        Transform tip { get; }
        /// <summary>The ChainIK target Transform.</summary>
        Transform target { get; }

        Transform baseTrans { get; }

        /// <summary>The maximum number of iterations allowed for the ChainIK algorithm to converge to a solution.</summary>
        int maxIterations { get; }
        /// <summary>
        /// The allowed distance between the tip and target Transform positions.
        /// When the distance is smaller than the tolerance, the algorithm has converged on a solution and will stop.
        /// </summary>
        float tolerance { get; }
        /// <summary>This is used to maintain the current position offset from the tip Transform to target Transform.</summary>
        bool maintainTargetPositionOffset { get; }
        /// <summary>This is used to maintain the current rotation offset from the tip Transform to target Transform.</summary>
        bool maintainTargetRotationOffset { get; }

        /// <summary>The path to the chain rotation weight property in the constraint component.</summary>
        string chainRotationWeightFloatProperty { get; }
        /// <summary>The path to the tip rotation weight property in the constraint component.</summary>
        string tipRotationWeightFloatProperty { get; }
    }

    public class ConstrainedIKJobBinder<T> : AnimationJobBinder<ConstrainedIKJob, T>
        where T : struct, IAnimationJobData, IConstrainedIKData
    {
        public override ConstrainedIKJob Create(Animator animator, ref T data, Component component)
        {
            MyConstraintsUtils.ExtractChainWithConstraint(data.root, data.tip, out Transform[] chain, out JointProperties[] jointProperties);

            var job = new ConstrainedIKJob();
            job.chain = new NativeArray<ReadWriteTransformHandle>(chain.Length, Allocator.Persistent, NativeArrayOptions.UninitializedMemory);
            job.linkLengths = new NativeArray<float>(chain.Length, Allocator.Persistent, NativeArrayOptions.UninitializedMemory);
            job.linkPositions = new NativeArray<Vector3>(chain.Length, Allocator.Persistent, NativeArrayOptions.UninitializedMemory);
            job.linkDirections = new NativeArray<Vector3>(chain.Length, Allocator.Persistent, NativeArrayOptions.UninitializedMemory);
            job.linkRotations = new NativeArray<Quaternion>(chain.Length, Allocator.Persistent, NativeArrayOptions.UninitializedMemory); 
            job.linkProperties = new NativeArray<JointProperties>(chain.Length, Allocator.Persistent, NativeArrayOptions.UninitializedMemory); 

            job.maxReach = 0f;

            int tipIndex = chain.Length - 1;
            for (int i = 0; i < chain.Length; ++i)
            {
                job.chain[i] = ReadWriteTransformHandle.Bind(animator, chain[i]);
                job.linkLengths[i] = (i != tipIndex) ? Vector3.Distance(chain[i].position, chain[i + 1].position) : 0f;
                job.maxReach += job.linkLengths[i];

                job.linkProperties[i] = jointProperties[i];
            }

            job.target = ReadOnlyTransformHandle.Bind(animator, data.target);
            job.targetOffset = AffineTransform.identity;
            job.baseTrans = ReadOnlyTransformHandle.Bind(animator, data.baseTrans);
            if (data.maintainTargetPositionOffset)
                job.targetOffset.translation = data.tip.position - data.target.position;
            if (data.maintainTargetRotationOffset)
                job.targetOffset.rotation = Quaternion.Inverse(data.target.rotation) * data.tip.rotation;

            job.chainRotationWeight = FloatProperty.Bind(animator, component, data.chainRotationWeightFloatProperty);
            job.tipRotationWeight = FloatProperty.Bind(animator, component, data.tipRotationWeightFloatProperty);

            var cacheBuilder = new AnimationJobCacheBuilder();
            job.maxIterationsIdx = cacheBuilder.Add(data.maxIterations);
            job.toleranceIdx = cacheBuilder.Add(data.tolerance);
            job.cache = cacheBuilder.Build();

            return job;
        }

        public override void Destroy(ConstrainedIKJob job)
        {
            job.chain.Dispose();
            job.linkLengths.Dispose();
            job.linkPositions.Dispose();
            job.linkDirections.Dispose();
            job.linkRotations.Dispose();
            job.linkProperties.Dispose();
            job.cache.Dispose();
        }

        /// <inheritdoc />
        public override void Update(ConstrainedIKJob job, ref T data)
        {
            job.cache.SetRaw(data.maxIterations, job.maxIterationsIdx);
            job.cache.SetRaw(data.tolerance, job.toleranceIdx);
        }
    }
}
