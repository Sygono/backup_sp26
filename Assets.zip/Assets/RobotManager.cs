using UnityEngine;

public class RobotManager : MonoBehaviour
{
    public Rigidbody rb;
    public Rigidbody targetRb; // Optional target Rigidbody for interaction
    public float brakingStrength = 10f;   // Higher = stronger braking
    public ForceMode forceMode = ForceMode.Acceleration;

    private InputSystem_Actions inputActions;
    private Vector2 nativeMoveInput;

    private void Awake()
    {
        inputActions = new InputSystem_Actions();
        inputActions.Player.Move.performed += ctx => nativeMoveInput = ctx.ReadValue<Vector2>();
        inputActions.Player.Move.canceled += _ => nativeMoveInput = Vector2.zero;

        if (rb == null)
            rb = GetComponent<Rigidbody>();
    }

    private void OnEnable() => inputActions.Enable();
    private void OnDisable() => inputActions.Disable();
    void FixedUpdate()
    {
        bool jumped = inputActions.Player.Jump.triggered;
        if (jumped)
        {
            Debug.Log("Jump pressed, applying force.");
            targetRb.AddForce(-transform.forward * 10f, ForceMode.Impulse);
        }

        ApplySelfBraking();
    }

    void ApplySelfBraking()
    {
        if (rb == null) return;

        Vector3 velocity = rb.linearVelocity;

        // If already almost stopped, skip
        if (velocity.sqrMagnitude < 0.0001f) return;

        // Apply force opposite to velocity
        Vector3 brakingForce = -velocity * brakingStrength;

        rb.AddForce(brakingForce, forceMode);
    }
}
