using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class SpringLinkWithSpillover : MonoBehaviour
{
    [Header("Bodies")]
    public Rigidbody selfRb;         // auto-filled from this GameObject if null
    public Rigidbody targetRb;

    [Header("Spring (linear)")]
    public float springStrength = 50f;     // k (N/m or accel if using Acceleration mode)
    public float damping = 5f;             // damps relative velocity along the link
    public float restLength = 0f;          // 0 = locked together; set >0 for rope-like
    public float maxForce = 50f;
    public ForceMode forceMode = ForceMode.Acceleration; // Acceleration makes it mass-independent

    void FixedUpdate()
    {
        if (!selfRb || !targetRb) return;

        // ----- SPRING FORCE (Hooke + damping along the link) -----
        Vector3 delta = targetRb.position - selfRb.position;
        float dist = delta.magnitude;

        if (dist > 1e-5f)
        {
            Vector3 dir = delta / dist;
            float x = dist - restLength;

            // Relative velocity along the link
            float vRel = Vector3.Dot(targetRb.linearVelocity - selfRb.linearVelocity, dir);

            // �� = k*x  and  damping = -d*vRel (both along the link)
            float scalarForce = (springStrength * x) + (damping * vRel);

            Vector3 force = dir * scalarForce;

            // Equal and opposite forces  or action-reaction
            selfRb.AddForce(force, forceMode);
            float accel = scalarForce - maxForce;
            if (accel > 0)
            {
                Debug.Log(accel);
                Vector3 split = -dir * accel; // Apply excess force as spillover
                targetRb.AddForce(split, forceMode);
            }
        }
    }
}
