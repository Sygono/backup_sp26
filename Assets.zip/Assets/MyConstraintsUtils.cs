using UnityEngine;
using Unity.Collections;
using System.Collections.Generic;

namespace UnityEngine.Animations.Rigging
{
    public static class MyConstraintsUtils
    {
        public static void ExtractChainWithConstraint(Transform root, Transform tip, out Transform[] _chain, out JointProperties[] _jointProperties) {
            if (!tip.IsChildOf(root)) {
                _chain = new Transform[0]{};
                _jointProperties = new JointProperties[0]{};
            }

            var chain = new List<Transform>();
            var jointProperties = new List<JointProperties>();

            Transform tmp = tip;
            while (tmp != root)
            {
                chain.Add(tmp);
                // Debug.Log(tmp);
                tmp = tmp.parent;
            }
            chain.Add(root);
            chain.Reverse();

            _chain = chain.ToArray();
            Debug.Log(chain.Count);
            foreach (var src in _chain) {
                var jc = src.GetComponent<ConstrainedJoint>();
                if (jc != null) {
                    jointProperties.Add(jc.GetJointProperty());
                } else {
                    jointProperties.Add(new JointProperties());
                }
            }
            _jointProperties = jointProperties.ToArray();
        }
    }
}
