using UnityEngine;
using System.Collections;

public static class DebugShapes
{
    public static Matrix4x4 matrix;
    public static void DrawLine(Vector3 pos, Vector3 end, Color col, float duration = 0f, Transform transform = null) {
        if (transform != null) {
            pos = transform.TransformPoint(pos);
            end = transform.TransformPoint(end);
        }
        Debug.DrawLine(pos, end, col, duration);
    }

    public static void DrawRay(Vector3 pos, Vector3 direction, Color col, float duration = 0f, Transform transform = null) {
        if (transform != null) {
            pos = transform.TransformPoint(pos);
            direction = transform.TransformDirection(direction);
        }
        Debug.DrawLine(pos, pos + direction, col, duration);
    }

    public static void DrawRay(Vector3 pos, Vector3 direction, float distance, Color col, float duration = 0f, Transform transform = null) {
        if (transform != null) {
            pos = transform.TransformPoint(pos);
            direction = transform.TransformDirection(direction);
        }
        Debug.DrawLine(pos, pos + direction.normalized * distance, col, duration);
    }

    public static void DrawPoint(Vector3 pos, float scale, Color col, float duration = 0f, Transform transform = null) {
        Vector3[] points = new Vector3[]
        {
            pos + (Vector3.up * scale),
            pos - (Vector3.up * scale),
            pos + (Vector3.right * scale),
            pos - (Vector3.right * scale),
            pos + (Vector3.forward * scale),
            pos - (Vector3.forward * scale)
        };

        if (transform != null) {
            for (int i=0; i<points.Length; i++) {
                points[i] = transform.TransformPoint(points[i]);
            }
        }

        Debug.DrawLine(points[0], points[1], col, duration);
        Debug.DrawLine(points[2], points[3], col, duration);
        Debug.DrawLine(points[4], points[5], col, duration);

        Debug.DrawLine(points[0], points[2], col, duration);
        Debug.DrawLine(points[0], points[3], col, duration);
        Debug.DrawLine(points[0], points[4], col, duration);
        Debug.DrawLine(points[0], points[5], col, duration);

        Debug.DrawLine(points[1], points[2], col, duration);
        Debug.DrawLine(points[1], points[3], col, duration);
        Debug.DrawLine(points[1], points[4], col, duration);
        Debug.DrawLine(points[1], points[5], col, duration);

        Debug.DrawLine(points[4], points[2], col, duration);
        Debug.DrawLine(points[4], points[3], col, duration);
        Debug.DrawLine(points[5], points[2], col, duration);
        Debug.DrawLine(points[5], points[3], col, duration);

    }

    public static void DrawCube(Vector3 pos, Vector3 scale, Color col, float duration = 0f, Transform transform = null) {
        Vector3 t = scale * 0.5f;

        Vector3[] p = new Vector3[]
        {
            pos + new Vector3(t.x,      t.y,    t.z),
            pos + new Vector3(-t.x,     t.y,    t.z),
            pos + new Vector3(-t.x,     -t.y,   t.z),
            pos + new Vector3(t.x,      -t.y,   t.z),
            pos + new Vector3(t.x,      t.y,    -t.z),
            pos + new Vector3(-t.x,     t.y,    -t.z),
            pos + new Vector3(-t.x,     -t.y,   -t.z),
            pos + new Vector3(t.x,      -t.y,   -t.z),
        };

        if (transform != null) {
            for (int i=0; i<p.Length; i++) {
                p[i] = transform.TransformPoint(p[i]);
            }
        }

        Debug.DrawLine(p[0], p[1], col, duration);
        Debug.DrawLine(p[1], p[2], col, duration);
        Debug.DrawLine(p[2], p[3], col, duration);
        Debug.DrawLine(p[3], p[0], col, duration);
    }

    public static void DrawCircle(Vector3 pos, Vector3 normal, float radius, Color col, float duration = 0, Transform transform = null) {

        int l = 16;

        //Choose a perpendicular vector
        Vector3 perpendicular;
        perpendicular = Vector3.ProjectOnPlane(Vector3.forward, normal);
        if (perpendicular == Vector3.zero) {
            perpendicular = Vector3.ProjectOnPlane(Vector3.right, normal);
        }
        perpendicular = perpendicular.normalized;


        Vector3[] p = new Vector3[l];

        //Lerping is problematic with an angle greater than 180
        for (int k = 0; k < l; k++) {
            p[k] = pos + Quaternion.AngleAxis(360.0f * k / l, normal) * perpendicular * radius;
        }

        // Draw circle
        for (int k = 0; k < l - 1; k++) {
            DrawLine(p[k], p[k + 1], col, duration, transform);
        }
        DrawLine(p[l - 1], p[0], col, duration, transform);
    }

    public static void DrawSphere(Vector3 pos, float radius, Color col, float duration = 0, Transform transform = null) {

        int l = 3;

        Vector3[] horiz = new Vector3[l];
        Vector3[] vert = new Vector3[l];
        Vector3[] Z = new Vector3[l];

        float step = 2 * radius / (l + 1);

        for (int k = 0; k < l; k++) {
            horiz[k] = pos - Vector3.right * radius + (k + 1) * step * Vector3.right;
            vert[k] = pos - Vector3.up * radius + (k + 1) * step * Vector3.up;
            Z[k] = pos - Vector3.forward * radius + (k + 1) * step * Vector3.forward;
            float angle = Mathf.Lerp(-Mathf.PI / 2, Mathf.PI / 2, (float)(k + 1) / (l + 1));
            float r = Mathf.Cos(angle) * radius; //Calculated wrong
            DrawCircle(horiz[k], Vector3.right, r, col, duration, transform);
            DrawCircle(vert[k], Vector3.up, r, col, duration, transform);
            DrawCircle(Z[k], Vector3.forward, r, col, duration, transform);
        }
        //Camera cam = UnityEditor.SceneView.lastActiveSceneView.camera;
        //if (cam != null) DrawCircle(pos, -cam.transform.forward, radius, col);
    }
    public static void DrawCircleSection(Vector3 pos, float minAngle, float maxAngle, Vector3 normal, Vector3 reference, float minRadius, float maxRadius, Color col, float duration = 0, Transform transform = null)
    {
        pos = transform.TransformPoint(pos);
        Vector3 min = Quaternion.AngleAxis(minAngle, normal) * reference;
        Vector3 max = Quaternion.AngleAxis(maxAngle, normal) * reference;
        min = transform.TransformDirection(min);
        max = transform.TransformDirection(max);
        normal = transform.TransformDirection(normal).normalized;
        DrawCircleSection(pos, min, max, normal, minRadius, maxRadius, col, duration);
    }

    public static void DrawCircleSection(Vector3 pos, Vector3 min, Vector3 max, Vector3 normal, float minRadius, float maxRadius, Color col, float duration = 0) {

        if (min == Vector3.zero || max == Vector3.zero) {
            Debug.LogWarning("Min and Max Vector not allowed to be zero.");
            return;
        }

        if (normal == Vector3.zero) {
            Debug.LogWarning("Normal Vector not allowed to be parallel.");
            return;
        }

        Vector3 projMin = Vector3.ProjectOnPlane(min, normal).normalized;
        Vector3 projMax = Vector3.ProjectOnPlane(max, normal).normalized;

        if (projMin == Vector3.zero || projMax == Vector3.zero) {
            Debug.LogWarning("Can't Draw Circle Section since one of the two Vectors are parallel to the normal.");
        }

        int l = 9;
        Vector3[] p = new Vector3[l];
        Vector3[] P = new Vector3[l];

        float angle = Vector3.Angle(projMin, projMax);

        for (int k = 0; k < l; k++) {
            p[k] = pos + Quaternion.AngleAxis(angle * k / (l - 1), normal) * projMin * minRadius;
            P[k] = pos + Quaternion.AngleAxis(angle * k / (l - 1), normal) * projMin * maxRadius;
        }

        // Draw circles
        for (int k = 0; k < l - 1; k++) {
            Debug.DrawLine(p[k], p[k + 1], col, duration);
            Debug.DrawLine(P[k], P[k + 1], col, duration);
        }

        // Connect inner to outer circle 
        Debug.DrawLine(p[0], P[0], col, duration);
        Debug.DrawLine(p[l - 1], P[l - 1], col, duration);
    }
}
