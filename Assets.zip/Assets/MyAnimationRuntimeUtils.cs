using UnityEngine;
using Unity.Collections;
using UnityEngine.Animations.Rigging;

namespace UnityEngine.Animations.Rigging
{
    public enum JointType
    {
        Free,
        Cone,
        Hinge,
        // Add other joint types as needed
    }

    [System.Serializable]
    public struct JointProperties {
        public JointType jointType;
        public Vector3 vector1;
        public Vector3 vector2;
        public float float1;
        public float float2;
    }

    public static class MyAnimationRuntimeUtils
    {
        public static bool SolveCCDIK(
            ref NativeArray<Vector3> linkPositions,
            ref NativeArray<Quaternion> linkRotations,
            ref NativeArray<JointProperties> linkProperties,
            Vector3 target,
            float tolerance,
            float maxReach,
            int maxIterations
            )
        {
            int tipIndex = linkPositions.Length - 1;
            float sqrTolerance = Square(tolerance);
            if (SqrDistance(linkPositions[tipIndex], target) > sqrTolerance)
            {
                var rootPos = linkPositions[0];
                int iteration = 0;

                do
                {
                    for(int i = tipIndex - 1; i >= 0; i--) {
                        var currentDir = (linkPositions[tipIndex] - linkPositions[i]).normalized;
                        var goalDir = (target - linkPositions[i]).normalized;
                        var childDir = (linkPositions[i + 1] - linkPositions[i]).normalized;
                        var parentRot = linkRotations[i];
                        var properties = linkProperties[i];
                        var delta = Quaternion.identity;
                        switch (properties.jointType) {
                            case JointType.Hinge:
                                var axis = parentRot * properties.vector1.normalized;
                                var refDir = parentRot * properties.vector2.normalized; // We will handle angle constraint later
                                goalDir = Vector3.ProjectOnPlane(goalDir, axis).normalized;
                                currentDir = Vector3.ProjectOnPlane(currentDir, axis).normalized;
                                childDir = Vector3.ProjectOnPlane(childDir, axis).normalized;   
                                float signedAngle = Vector3.SignedAngle(currentDir, goalDir, axis);
                                float childAngle = Vector3.SignedAngle(refDir, childDir, axis);
                                float newChildAnglle = Mathf.Clamp(childAngle + signedAngle, properties.float1, properties.float2);
                                delta = Quaternion.AngleAxis(newChildAnglle - childAngle, axis);
                                break;
                            default:
                                break;
                        }
                        for (int j = i + 1; j <= tipIndex; j++) {
                            linkRotations[j] = delta * linkRotations[j];
                            linkPositions[j] = linkPositions[i] + delta * (linkPositions[j] - linkPositions[i]);
                        }
                    }

                }
                while ((SqrDistance(linkPositions[tipIndex], target) > sqrTolerance) && (++iteration < maxIterations));
                return true;
            }
            return false;
        }

        public static bool SolveFABRIK(
            ref NativeArray<Vector3> linkPositions,
            ref NativeArray<float> linkLengths,
            ref NativeArray<Vector3> linkdirections, // buffer
            ref NativeArray<Quaternion> linkRotations,
            ref NativeArray<JointProperties> linkProperties,
            Vector3 target,
            float tolerance,
            float maxReach,
            int maxIterations
            )
        {
            // If the target is unreachable
            var rootToTargetDir = target - linkPositions[0];
            if (rootToTargetDir.sqrMagnitude > Square(maxReach))
            {
                // Line up chain towards target
                var dir = rootToTargetDir.normalized;
                for (int i = 1; i < linkPositions.Length; ++i)
                    linkPositions[i] = linkPositions[i - 1] + dir * linkLengths[i - 1];

                return true;
            }
            else
            {
                int tipIndex = linkPositions.Length - 1;
                float sqrTolerance = Square(tolerance);
                if (SqrDistance(linkPositions[tipIndex], target) > sqrTolerance)
                {
                    var rootPos = linkPositions[0];
                    int iteration = 0;

                    do
                    {
                        // Forward reaching phase
                        // Set tip to target and propagate displacement to rest of chain
                        linkdirections[tipIndex - 1] = (linkPositions[tipIndex] - linkPositions[tipIndex - 1]).normalized;
                        linkPositions[tipIndex] = target;
                        for (int i = tipIndex - 1; i > -1; --i) {
                            if (i > 0) linkdirections[i - 1] = (linkPositions[i] - linkPositions[i - 1]).normalized;
                            linkPositions[i] = linkPositions[i + 1] + ((linkPositions[i] - linkPositions[i + 1]).normalized * linkLengths[i]);
                        }

                        // Backward reaching phase
                        // Set root back at it's original position and propagate displacement to rest of chain
                        linkPositions[0] = rootPos;
                        for (int i = 1; i < linkPositions.Length; ++i) {
                            linkPositions[i] = linkPositions[i - 1] + ((linkPositions[i] - linkPositions[i - 1]).normalized * linkLengths[i - 1]);
                            var parentRot = linkRotations[i - 1];
                            var currentDir = linkdirections[i - 1];
                            var goalDir = (linkPositions[i] - linkPositions[i - 1]).normalized;
                            var properties = linkProperties[i - 1];
                            switch(properties.jointType) {
                                case JointType.Hinge:
                                    var axis = parentRot * properties.vector1.normalized;
                                    var refDir = parentRot * properties.vector2.normalized; // We will handle angle constraint later
                                    goalDir = Vector3.ProjectOnPlane(goalDir, axis).normalized;

                                    float signedAngle = Vector3.SignedAngle(refDir, goalDir, axis);
                                    signedAngle = Mathf.Clamp(signedAngle, properties.float1, properties.float2);
                                    goalDir = Quaternion.AngleAxis(signedAngle, axis) * refDir;
                                    break;
                                default:
                                    break;
                            }
                            linkPositions[i] = linkPositions[i - 1] + goalDir * linkLengths[i - 1];
                            var delta = Quaternion.FromToRotation(currentDir, goalDir);
                            linkRotations[i] = delta * linkRotations[i];
                        }
                    }
                    while ((SqrDistance(linkPositions[tipIndex], target) > sqrTolerance) && (++iteration < maxIterations));

                    return true;
                }
            }

            return false;
        }

        static void ApplyConstraint(            
            ref NativeArray<Vector3> linkPositions,
            ref NativeArray<float> linkLengths,
            ref NativeArray<Quaternion> linkRotations,
            ref NativeArray<JointProperties> linkProperties,
            Vector3 currentDir,
            int i,
            bool isForward
            ) 
        {
            var parentRot = linkRotations[i];
            var goalDir = (linkPositions[i + 1] - linkPositions[i]).normalized;
            var properties = linkProperties[i];
            switch(properties.jointType) {
                case JointType.Hinge:
                    var axis = parentRot * properties.vector1.normalized;
                    var refDir = parentRot * properties.vector2.normalized; // We will handle angle constraint later
                    goalDir = Vector3.ProjectOnPlane(goalDir, axis).normalized;

                    float signedAngle = Vector3.SignedAngle(refDir, goalDir, axis);
                    signedAngle = Mathf.Clamp(signedAngle, properties.float1, properties.float2);
                    goalDir = Quaternion.AngleAxis(signedAngle, axis) * refDir;
                    break;
                default:
                    break;
            }
            if (isForward) {
                linkPositions[i - 1] = linkPositions[i] + goalDir * linkLengths[i];
            } else {
                linkPositions[i] = linkPositions[i - 1] + goalDir * linkLengths[i];
            }
            var delta = Quaternion.FromToRotation(currentDir, goalDir);
            linkRotations[i] = delta * linkRotations[i];
        }

        public static float Square(float value)
        {
            return value * value;
        }

        public static float SqrDistance(Vector3 lhs, Vector3 rhs)
        {
            return (rhs - lhs).sqrMagnitude;
        }
    }
}