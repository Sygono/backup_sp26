using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class AngularSpringToRotation : MonoBehaviour
{
    public Rigidbody rb;
    public Quaternion targetRotation = Quaternion.identity;
    public float springStrength = 100f;   // Spring torque coefficient (like 'k')
    public float damping = 10f;            // Damping coefficient
    public ForceMode forceMode = ForceMode.Acceleration;

    void Awake()
    {
        if (rb == null)
            rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        ApplyAngularSpring(rb, targetRotation, springStrength, damping, forceMode);
    }

    void ApplyAngularSpring(Rigidbody body, Quaternion target, float k, float d, ForceMode mode)
    {
        // 1. Calculate rotation delta (relative rotation from current to target)
        Quaternion q = target * Quaternion.Inverse(body.rotation);
        q.ToAngleAxis(out float angleInDegrees, out Vector3 axis);

        // Avoid problems with zero rotation
        if (angleInDegrees > 180f) angleInDegrees -= 360f;
        if (Mathf.Approximately(angleInDegrees, 0f) || axis == Vector3.zero)
            return;

        // Convert to radians:
        float angleInRad = angleInDegrees * Mathf.Deg2Rad;

        // 2. Spring torque: �� = k * �� * axis
        Vector3 springTorque = axis.normalized * (k * angleInRad);

        // 3. Damping torque: ��_damp = -d * angularVelocity
        Vector3 dampingTorque = -body.angularVelocity * d;

        // 4. Total torque
        Vector3 totalTorque = springTorque + dampingTorque;

        // 5. Apply torque
        body.AddTorque(totalTorque, mode);
    }
}
