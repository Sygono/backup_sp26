using UnityEngine;

namespace UnityEngine.Animations.Rigging
{
    public class ConstrainedJoint : MonoBehaviour
    {
        [SerializeField]
        public JointProperties properties;
        // Start is called once before the first execution of Update after the MonoBehaviour is created
        void Start()
        {
            
        }

        // Update is called once per frame
        void Update()
        {
            
        }

        public JointProperties GetJointProperty() {
            return properties;
        }

        private void OnDrawGizmos()
        {
            DebugShapes.DrawRay(transform.localPosition, properties.vector1.normalized, Color.lightCyan, 0, transform.parent);
            DebugShapes.DrawRay(transform.localPosition, properties.vector2.normalized, Color.darkCyan, 0, transform.parent);

            DebugShapes.DrawCircleSection(transform.parent.InverseTransformPoint(transform.position), properties.float1, properties.float2, properties.vector1, properties.vector2, 0.5f, 1f, Color.yellow, 0, transform.parent);

        }


}
}
