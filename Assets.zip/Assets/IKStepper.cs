using UnityEngine;
using System.Collections;

[System.Serializable]
public struct StepRay
{
    public Vector3 originOffset;  // local-space offset for the ray's start
    public Vector3 direction;     // direction of the cast (normalized, local space)
    public float length;          // cast length
    public bool useSphereCast;    // toggle between SphereCast and Raycast
    public float radius;          // sphere radius, if SphereCast 

    public bool Shoot(out RaycastHit hit, LayerMask groundMask, Transform transform = null, bool applyRotation = true) {
        Vector3 worldOrigin = originOffset;
        Vector3 worldDir = direction.normalized;
        if (transform!=null) {
            worldOrigin = transform.TransformPoint(worldOrigin);
            if (applyRotation) worldDir = transform.TransformDirection(worldDir);
        }
        if (useSphereCast ? Physics.SphereCast(worldOrigin, radius, worldDir, out hit, length, groundMask)
        : Physics.Raycast(worldOrigin, worldDir, out hit, length, groundMask)) {
            return true;
        }
        return false;
    }

    public void Draw(Color color, float time = 0, Transform transform = null) {
        if (useSphereCast) {
            int steps = 10;
            for (int i = 1; i <= steps; i++)
            {
                float t = (float)i / steps;
                Vector3 center = originOffset + direction.normalized * t * length;
                DebugShapes.DrawSphere(center, radius, color, time, transform);
            }
        }
        DebugShapes.DrawRay(originOffset, direction.normalized * length, color, time, transform);
    }
}

public struct TargetInfo {
    public Vector3 point;
    public Vector3 normal;

    public TargetInfo(Vector3 _point, Vector3 _normal) {
        point = _point;
        normal = _normal;
    }

    public static TargetInfo Lerp(TargetInfo t0, TargetInfo t1, float t) {
        return new TargetInfo(Vector3.Lerp(t0.point, t1.point, t), Vector3.Lerp(t0.normal, t1.normal, t));
    }

    public void Draw(Color color, float duration = 0, Transform transform = null) {
        DebugShapes.DrawSphere(point, 0.5f, color, duration, transform);
        DebugShapes.DrawRay(point, normal.normalized * 1f, color, duration, transform);
    }
}

public class IKStepper : MonoBehaviour
{
    public Transform ikTarget;
    public LayerMask groundMask;
    public float stepDuration = 1f;
    public float stepHeight = 1f;
    public AnimationCurve stepHeightCurve;

    public StepRay[] raySettings;  // prioritized list of rays
    public Vector3 defaultPos;

    public TargetInfo currentTarget;
    public TargetInfo desiredTarget;
    TargetInfo defaultTarget;
    public TargetInfo defaultTargetWorld => transform.TransformTargetInfo(defaultTarget);
    public bool grounding;
    public bool isStepping;
    float stepTimer;

    void Start()
    {
        defaultTarget = new TargetInfo(defaultPos, Vector3.up);
        ikTarget.position = transform.TransformPoint(defaultPos);
        ikTarget.rotation = Quaternion.FromToRotation(ikTarget.up, transform.up) * ikTarget.rotation;
        desiredTarget = defaultTargetWorld;
        currentTarget = desiredTarget;
    }

    void Update() {
        grounding = false;
        if (!isStepping) desiredTarget = defaultTargetWorld;
        foreach (var ray in raySettings)
        {
            if (ray.Shoot(out var hit, groundMask, transform)) {
                desiredTarget = new TargetInfo(hit.point, hit.normal);
                grounding = true;
                break;
            }
        }
    }

    // public bool TryStep() {
    //     if (isStepping) return false;
    //     if (Vector3.Distance(desiredTarget.point, currentTarget.point) < stepDistance || !grounding) return false;
    //     StartCoroutine(Step());
    //     return true;
    // }

    // public bool TryAir() {
    //     if (isStepping) return false;
    //     if (Vector3.Distance(desiredTarget.point, currentTarget.point) < stepDistance || grounding) return false;
    //     StartCoroutine(Air());
    //     return true;
    // }

    public void StartStep() {
        StartCoroutine(Step());
    }

    IEnumerator Step() {
        isStepping = true;
        stepTimer = 0;
        float t = 0;
        while(t < 1) {
            TargetInfo baseTarget = TargetInfo.Lerp(currentTarget, desiredTarget, t);
            float heightOffset = stepHeightCurve.Evaluate(t);

            baseTarget.point = baseTarget.point + transform.up * heightOffset * stepHeight;
            baseTarget.Draw(Color.yellow);
            ikTarget.position = baseTarget.point;
            ikTarget.rotation = Quaternion.FromToRotation(ikTarget.up, baseTarget.normal) * ikTarget.rotation;

            stepTimer += Time.deltaTime / stepDuration;
            t = Mathf.Clamp01(stepTimer);
            yield return null;
        }
        isStepping = false;
        ikTarget.position = desiredTarget.point;
        ikTarget.rotation = Quaternion.FromToRotation(ikTarget.up, desiredTarget.normal) * ikTarget.rotation;
        currentTarget = desiredTarget;
    }

    public void ReturnToDefault() {
        float returnSpeed = stepHeight / stepDuration * 10f;
        var delta = returnSpeed * Time.deltaTime;
        var worldTarget = defaultTargetWorld;
        if (Vector3.Distance(currentTarget.point, worldTarget.point) < delta) {
            currentTarget = worldTarget;
        } else {
            Debug.Log("returning");
            // currentTarget.point += (worldTarget.point - currentTarget.point).normalized * delta;
            currentTarget.point = Vector3.Lerp(currentTarget.point, worldTarget.point, 0.1f);
        }
        ikTarget.position = currentTarget.point;
    }

    void OnDrawGizmos()
    {
        if (raySettings == null) return;

        var worldMatrix = Gizmos.matrix;

        foreach (var ray in raySettings)
        {
            ray.Draw(Color.yellow, 0, transform);
        }
        defaultTargetWorld.Draw(Color.blue);
        desiredTarget.Draw(grounding?Color.green:Color.red);
        currentTarget.Draw(Color.cyan);


    }
}
