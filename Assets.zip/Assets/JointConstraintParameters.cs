using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum JointType
{
    Free,       // No constraints
    Hinge,      // Rotation around a single axis
    Cone        // Rotation within a conical limit
}
public struct JointConstraintParameters
{
    public JointType jointType;
    public Vector3 vector1;
    public float float1;
    public float float2;


}
